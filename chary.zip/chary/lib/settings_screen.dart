import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'lock_store.dart';
import 'native_bridge.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> with WidgetsBindingObserver {
  bool _hasPin = false;
  bool _disguise = false;
  bool _admin = false;
  int _relock = 30;
  int _escalate = 5;

  static const adminWarning =
      'Stops someone uninstalling Chary to remove your alerts. To uninstall it yourself '
      'later, switch this off here first (it asks for your PIN if you set one), or in '
      'Android Settings > Security > Device admin apps. It cannot stop a person who '
      'knows your phone passcode from switching it off in Android Settings.';

  static const forgotWarning =
      'If you forget this PIN the only way back in is to clear the app data in Android '
      'Settings, which erases your guardians and saved evidence.';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(); // back from the admin screen
  }

  Future<void> _load() async {
    final hasPin = await LockStore.hasPin();
    final dis = await LockStore.disguise();
    final relock = await LockStore.relockSeconds();
    final esc = await LockStore.escalationMinutes();
    final admin = await Native.adminActive();
    if (!mounted) return;
    setState(() {
      _hasPin = hasPin;
      _disguise = hasPin && dis;
      _relock = relock;
      _escalate = esc;
      _admin = admin;
    });
  }

  /// Asks for a PIN. Returns null if cancelled.
  Future<String?> _askPin(String title, {String? note, bool checkLength = false}) {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (note != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(note)),
          TextField(
            controller: c,
            autofocus: true,
            obscureText: true,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(LockStore.maxPin),
            ],
            decoration: InputDecoration(
                labelText: checkLength
                    ? '${LockStore.minPin} to ${LockStore.maxPin} digits'
                    : 'PIN'),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              final v = c.text;
              if (checkLength && v.length < LockStore.minPin) return;
              if (v.isEmpty) return;
              Navigator.pop(ctx, v);
            },
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _toast(String m) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(m)));

  /// Confirms the current PIN. True if there is no PIN or it matched.
  Future<bool> _confirmCurrent() async {
    if (!_hasPin) return true;
    final cur = await _askPin('Enter current PIN');
    if (cur == null) return false;
    if (await LockStore.verify(cur)) return true;
    _toast('Wrong PIN');
    return false;
  }

  Future<void> _setPin() async {
    if (!await _confirmCurrent()) return;
    final a = await _askPin(_hasPin ? 'New PIN' : 'Choose a PIN', note: forgotWarning, checkLength: true);
    if (a == null) return;
    final b = await _askPin('Enter it again', checkLength: true);
    if (b == null) return;
    if (a != b) {
      _toast('The PINs did not match');
      return;
    }
    await LockStore.setPin(a);
    _toast('PIN saved');
    _load();
  }

  Future<void> _removePin() async {
    if (!await _confirmCurrent()) return;
    await LockStore.clearPin();
    _toast('PIN removed');
    _load();
  }

  Future<void> _toggleDisguise(bool on) async {
    await LockStore.setDisguise(on);
    _toast(on
        ? 'Done. The icon may take a few seconds to change on your home screen.'
        : 'Icon restored.');
    _load();
  }

  Future<void> _toggleAdmin(bool on) async {
    if (on) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Block uninstall?'),
          content: const Text(adminWarning),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Continue')),
          ],
        ),
      );
      if (ok == true) await Native.requestAdmin();
    } else {
      if (!await _confirmCurrent()) return;
      await Native.removeAdmin();
      await Future.delayed(const Duration(milliseconds: 400));
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final android = Platform.isAndroid;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(children: [
        const _Header('Privacy'),
        ListTile(
          leading: const Icon(Icons.pin),
          title: const Text('App PIN'),
          subtitle: Text(_hasPin
              ? 'On. SOS still works from the lock screen without it.'
              : 'Off. Anyone who opens the app can see everything.'),
          trailing: _hasPin
              ? Row(mainAxisSize: MainAxisSize.min, children: [
                  TextButton(onPressed: _setPin, child: const Text('Change')),
                  TextButton(onPressed: _removePin, child: const Text('Remove')),
                ])
              : FilledButton(onPressed: _setPin, child: const Text('Set PIN')),
        ),
        ListTile(
          leading: const Icon(Icons.timer_outlined),
          title: const Text('Lock again after'),
          enabled: _hasPin,
          trailing: DropdownButton<int>(
            value: const [0, 30, 120, 300].contains(_relock) ? _relock : 30,
            onChanged: !_hasPin
                ? null
                : (v) async {
                    if (v == null) return;
                    await LockStore.setRelockSeconds(v);
                    _load();
                  },
            items: const [
              DropdownMenuItem(value: 0, child: Text('Immediately')),
              DropdownMenuItem(value: 30, child: Text('30 seconds')),
              DropdownMenuItem(value: 120, child: Text('2 minutes')),
              DropdownMenuItem(value: 300, child: Text('5 minutes')),
            ],
          ),
        ),
        if (android)
          SwitchListTile(
            secondary: const Icon(Icons.calculate_outlined),
            title: const Text('Disguise as a calculator'),
            subtitle: Text(_hasPin
                ? 'The icon and name become "Calculator" and it opens as a working '
                    'calculator. Type your PIN then = to open Chary. Hold the % key for '
                    '3 seconds to send an SOS (you feel a buzz, nothing is shown).'
                : 'Set a PIN first. The PIN is what opens the app from the calculator.'),
            value: _disguise,
            onChanged: _hasPin ? _toggleDisguise : null,
          ),
        if (android) ...[
          SwitchListTile(
            secondary: const Icon(Icons.admin_panel_settings_outlined),
            title: const Text('Block uninstall'),
            subtitle: const Text(adminWarning),
            value: _admin,
            onChanged: _toggleAdmin,
          ),
          const _Header('Alerts'),
          ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('Remind guardians who do not reply'),
            subtitle: const Text('Guardians are asked to reply to the alert. Up to 3 '
                'reminders go to anyone who has not. The app only sees WHO replied, '
                'never what they wrote. Works while the app is still running.'),
            trailing: DropdownButton<int>(
              value: const [0, 2, 5, 10].contains(_escalate) ? _escalate : 5,
              onChanged: (v) async {
                if (v == null) return;
                await LockStore.setEscalationMinutes(v);
                _load();
              },
              items: const [
                DropdownMenuItem(value: 0, child: Text('Off')),
                DropdownMenuItem(value: 2, child: Text('2 min')),
                DropdownMenuItem(value: 5, child: Text('5 min')),
                DropdownMenuItem(value: 10, child: Text('10 min')),
              ],
            ),
          ),
          const ListTile(
            leading: Icon(Icons.dashboard_customize_outlined),
            title: Text('Quick Settings tile'),
            subtitle: Text('Swipe down twice, tap the pencil or Edit, and drag "Chary SOS" '
                'into your tiles. Tapping it starts a 5 second countdown you can cancel, '
                'then sends the alert, even while the app is locked.'),
          ),
        ],
        const _Header('Author and publisher'),
        const ListTile(leading: Icon(Icons.verified_user), title: Text('maxidoizooh254')),
        const _Contact(Icons.chat, Color(0xFF25D366), 'WhatsApp', '+254 115 710 055', 'https://wa.me/254115710055'),
        const _Contact(Icons.camera_alt, Color(0xFFE1306C), 'Instagram', 'maxtech_058', 'https://www.instagram.com/maxtech_058'),
        const _Contact(Icons.music_note, Color(0xFF69C9D0), 'TikTok', '@maxtech_058', 'https://www.tiktok.com/@maxtech_058'),
        const _Contact(Icons.play_circle_fill, Color(0xFFFF0000), 'YouTube', '@MaxidoEnt', 'https://www.youtube.com/@MaxidoEnt'),
      ]),
    );
  }
}

class _Contact extends StatelessWidget {
  const _Contact(this.icon, this.color, this.name, this.handle, this.url);
  final IconData icon;
  final Color color;
  final String name, handle, url;
  @override
  Widget build(BuildContext context) => ListTile(
        leading: Icon(icon, color: color),
        title: Text(name),
        subtitle: Text(handle),
        onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
      );
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 4),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleSmall
                ?.copyWith(color: Theme.of(context).colorScheme.primary)),
      );
}
