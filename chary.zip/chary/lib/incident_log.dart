import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';
import 'evidence.dart';

class Incident {
  final int id; // creation time in ms, also the upload id
  final String time;
  final double? lat;
  final double? lng;
  final String text;
  final bool synced;
  Incident(this.id, this.time, this.lat, this.lng, this.text, this.synced);

  Incident markSynced() => Incident(id, time, lat, lng, text, true);

  Map<String, dynamic> toJson() =>
      {'id': id, 'time': time, 'lat': lat, 'lng': lng, 'text': text, 'synced': synced};

  factory Incident.fromJson(Map<String, dynamic> j) => Incident(
        (j['id'] as num).toInt(),
        j['time'] as String? ?? '',
        (j['lat'] as num?)?.toDouble(),
        (j['lng'] as num?)?.toDouble(),
        j['text'] as String? ?? '',
        j['synced'] as bool? ?? false,
      );
}

/// A private diary of stalking / harassment incidents. Each entry is copied to the relay as soon
/// as the phone has any connection, so the record survives if the phone is lost or destroyed,
/// and guardians (or the police) can read the whole timeline from one link.
class IncidentLog {
  static const _listKey = 'incidents';
  static const _tokenKey = 'log_token';

  static bool get syncEnabled => Config.relayUrl.isNotEmpty;

  static Future<List<Incident>> all() async {
    final raw = (await SharedPreferences.getInstance()).getString(_listKey);
    if (raw == null) return [];
    try {
      final l = (jsonDecode(raw) as List)
          .map((e) => Incident.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
      l.sort((a, b) => b.id.compareTo(a.id));
      return l;
    } catch (_) {
      return [];
    }
  }

  static Future<void> _save(List<Incident> l) async => (await SharedPreferences.getInstance())
      .setString(_listKey, jsonEncode(l.map((e) => e.toJson()).toList()));

  static Future<String> _token() async {
    final p = await SharedPreferences.getInstance();
    var t = p.getString(_tokenKey);
    if (t == null) {
      final r = Random.secure();
      t = List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
      await p.setString(_tokenKey, t);
    }
    return t;
  }

  /// Link guardians or the police can open to read the whole log. Null if there is no relay.
  static Future<String?> link() async {
    if (!syncEnabled) return null;
    return '${Config.relayUrl.replaceFirst(RegExp(r'/+$'), '')}/log/${await _token()}';
  }

  /// Saves an entry on the phone first, then tries to upload it.
  static Future<Incident> add(String text) async {
    final pos = await Evidence.quickPosition();
    final now = DateTime.now();
    final e = Incident(now.millisecondsSinceEpoch, now.toIso8601String().substring(0, 16),
        pos?.latitude, pos?.longitude, text.trim(), false);
    final l = await all();
    await _save([e, ...l]);
    sync();
    return e;
  }

  static Future<void> delete(int id) async {
    final l = await all();
    await _save(l.where((e) => e.id != id).toList());
  }

  static bool _syncing = false;

  /// Uploads entries the relay has not confirmed. Safe to call often; does nothing offline.
  static Future<void> sync() async {
    if (!syncEnabled || _syncing) return;
    _syncing = true;
    try {
      final l = await all();
      if (l.every((e) => e.synced)) return;
      final token = await _token();
      final base = Config.relayUrl.replaceFirst(RegExp(r'/+$'), '');
      final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
      try {
        for (final e in l.where((e) => !e.synced).toList().reversed) {
          try {
            final body = utf8.encode(
                jsonEncode({'time': e.time, 'lat': e.lat, 'lng': e.lng, 'text': e.text}));
            final req = await client.postUrl(Uri.parse('$base/incident/$token/${e.id}'));
            req.headers.set('X-Key', Config.relayKey);
            req.headers.contentType = ContentType.json;
            req.contentLength = body.length;
            req.add(body);
            final res = await req.close().timeout(const Duration(seconds: 20));
            await res.drain();
            if (res.statusCode < 200 || res.statusCode > 299) break;
            // re-read so entries added while uploading are not overwritten
            final fresh = await all();
            await _save([for (final x in fresh) x.id == e.id ? x.markSynced() : x]);
          } catch (_) {
            break; // offline: try again later
          }
        }
      } finally {
        client.close();
      }
    } finally {
      _syncing = false;
    }
  }
}
