import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'incident_log.dart';

class IncidentsScreen extends StatefulWidget {
  const IncidentsScreen({super.key});
  @override
  State<IncidentsScreen> createState() => _IncidentsScreenState();
}

class _IncidentsScreenState extends State<IncidentsScreen> {
  List<Incident> _items = [];
  String? _link;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
    IncidentLog.sync().then((_) => _refresh());
  }

  Future<void> _refresh() async {
    final l = await IncidentLog.all();
    final link = await IncidentLog.link();
    if (!mounted) return;
    setState(() {
      _items = l;
      _link = link;
      _loading = false;
    });
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _add() async {
    final c = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('What happened?'),
        content: TextField(
          controller: c,
          autofocus: true,
          maxLines: 5,
          minLines: 3,
          maxLength: 1000,
          decoration: const InputDecoration(
              hintText: 'Who, what they did, what they wore, vehicle number plate, '
                  'where. Time and place are added for you.'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
              onPressed: () {
                if (c.text.trim().isNotEmpty) Navigator.pop(ctx, c.text);
              },
              child: const Text('Save')),
        ],
      ),
    );
    if (text == null) return;
    await IncidentLog.add(text);
    await _refresh();
    // give the background upload a moment, then show whether it got through
    Future.delayed(const Duration(seconds: 4), () {
      if (mounted) _refresh();
    });
  }

  Future<void> _delete(Incident e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete this entry?'),
        content: const Text('It is removed from this phone. A copy already uploaded to the '
            'relay is NOT removed.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await IncidentLog.delete(e.id);
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Incident log'), actions: [
        if (_link != null)
          IconButton(
            tooltip: 'Share the log link',
            icon: const Icon(Icons.share),
            onPressed: () => Share.share(
                'My incident log (a record of what has been happening to me): $_link'),
          ),
        if (_link != null)
          IconButton(
            tooltip: 'Copy link',
            icon: const Icon(Icons.link),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: _link!));
              _toast('Link copied.');
            },
          ),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('Add incident'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 96), children: [
              Card(
                color: Colors.blue.shade50,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(IncidentLog.syncEnabled
                      ? 'Write down every time someone follows, watches or threatens you. Each '
                          'entry is copied off your phone as soon as you have any connection '
                          '(data or Wi-Fi), so it is safe even if this phone is lost or destroyed. '
                          'Share the link with someone you trust. Take it to the police and ask '
                          'for an OB number.'
                      : 'Entries are stored on this phone only (no relay is set up), so they '
                          'are lost if the phone is lost.'),
                ),
              ),
              if (_items.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Text('No entries yet.', textAlign: TextAlign.center),
                ),
              for (final e in _items)
                Card(
                  child: ListTile(
                    title: Text(e.text),
                    subtitle: Text('${e.time.replaceFirst('T', ' ')}'
                        '${e.lat == null ? '' : '   ${e.lat!.toStringAsFixed(4)}, ${e.lng!.toStringAsFixed(4)}'}'
                        '\n${!IncidentLog.syncEnabled ? 'On this phone only' : e.synced ? 'Saved off the phone' : 'Waiting for a connection...'}'),
                    isThreeLine: true,
                    trailing: IconButton(
                        icon: const Icon(Icons.delete_outline), onPressed: () => _delete(e)),
                  ),
                ),
            ]),
    );
  }
}
