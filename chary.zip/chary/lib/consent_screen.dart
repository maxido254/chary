import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Plain-language disclosure shown before first use. The user must read it and agree.
class Consent {
  static const _key = 'consent_v1';
  static Future<bool> accepted() async =>
      (await SharedPreferences.getInstance()).getBool(_key) ?? false;
  static Future<void> accept() async =>
      (await SharedPreferences.getInstance()).setBool(_key, true);
}

class ConsentScreen extends StatefulWidget {
  final VoidCallback onAccepted;
  const ConsentScreen({super.key, required this.onAccepted});
  @override
  State<ConsentScreen> createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool _own = false;

  static const _items = <(IconData, String, String)>[
    (Icons.sms, 'Text messages',
        'When YOU press SOS, Chary sends a text with your location to the guardians YOU chose. '
            'It can also see which guardian numbers texted you back (never what they wrote), '
            'so it knows who has seen your alert.'),
    (Icons.location_on, 'Your location',
        'Only after YOU press SOS: your location is shared every 2 minutes with your guardians '
            'until you stop it.'),
    (Icons.mic, 'Microphone and cameras',
        'Only after YOU press SOS or take a photo: audio is recorded and a selfie and a back '
            'photo are taken. They are stored encrypted on your phone. If a relay is set up, '
            'they are also sent to the private link your guardians receive.'),
    (Icons.admin_panel_settings, 'Optional: block uninstall, calculator disguise',
        'Both are OFF until you turn them on in Settings. Block uninstall stops someone else '
            'removing the app; you can switch it off any time in Settings.'),
    (Icons.group_off, 'Only for your own phone',
        'Never install Chary on someone else\'s phone or use it to watch another person. '
            'That is illegal in Kenya and in most countries.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Before you start')),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Image.asset('assets/logo.png', height: 72),
              const SizedBox(height: 12),
              const Text('Chary is a personal safety app. Here is exactly what it does with '
                  'your phone, and when:',
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 12),
              for (final (icon, title, body) in _items)
                Card(
                  child: ListTile(
                    leading: Icon(icon, color: Colors.red.shade700),
                    title: Text(title),
                    subtitle: Text(body),
                  ),
                ),
              CheckboxListTile(
                value: _own,
                onChanged: (v) => setState(() => _own = v ?? false),
                controlAffinity: ListTileControlAffinity.leading,
                title: const Text('This is my own phone, and I agree to the above.'),
              ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _own
                    ? () async {
                        await Consent.accept();
                        widget.onAccepted();
                      }
                    : null,
                child: const Padding(
                  padding: EdgeInsets.all(12),
                  child: Text('I understand, continue'),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
