import 'dart:io';
import 'package:flutter/services.dart';

/// A text received from a number (we never read the content, only who sent it and when).
class AckEntry {
  final String number;
  final int millis;
  AckEntry(this.number, this.millis);
}

/// Thin wrapper over the Android side. Every call is safe to make on iOS / when native fails.
class Native {
  static const _ch = MethodChannel('chary/sms');

  static Future<T?> _call<T>(String m, [Map<String, dynamic>? args]) async {
    if (!Platform.isAndroid) return null;
    try {
      return await _ch.invokeMethod<T>(m, args);
    } catch (_) {
      return null;
    }
  }

  /// True once if the Quick Settings tile launched the app.
  static Future<bool> consumeSos() async => await _call<bool>('consumeSos') ?? false;

  static Future<List<AckEntry>> acks() async {
    final raw = await _call<List<dynamic>>('getAcks') ?? const [];
    final out = <AckEntry>[];
    for (final e in raw) {
      final parts = e.toString().split('|');
      if (parts.length != 2) continue;
      final ts = int.tryParse(parts[1]);
      if (ts != null) out.add(AckEntry(parts[0], ts));
    }
    return out;
  }

  static Future<void> clearAcks() => _call('clearAcks');

  /// Swap the launcher icon and name between "Chary" and "Calculator".
  static Future<void> setDisguise(bool on) => _call('setDisguise', {'on': on});

  /// Name shown in the recent-apps switcher.
  static Future<void> setTaskLabel(String label) => _call('setTaskLabel', {'label': label});

  static Future<bool> adminActive() async => await _call<bool>('adminActive') ?? false;
  static Future<void> requestAdmin() => _call('requestAdmin');
  static Future<void> removeAdmin() => _call('removeAdmin');
}
