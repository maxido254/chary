import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'native_bridge.dart';

/// PIN, disguise and timing preferences. The PIN is stored only as a salted hash.
class LockStore {
  static const _hashK = 'pin_hash';
  static const _saltK = 'pin_salt';
  static const _lenK = 'pin_len';
  static const _disK = 'disguise_on';
  static const _relockK = 'relock_secs';
  static const _escK = 'escalate_min';

  static const minPin = 4;
  static const maxPin = 8;

  /// Bumped whenever lock settings change so the Gate can reload.
  static final ValueNotifier<int> changes = ValueNotifier(0);
  static void _changed() => changes.value++;

  static Future<SharedPreferences> get _p => SharedPreferences.getInstance();

  static String _hash(String salt, String pin) =>
      sha256.convert(utf8.encode('$salt:$pin')).toString();

  static Future<bool> hasPin() async => (await _p).getString(_hashK) != null;

  static Future<int> pinLength() async => (await _p).getInt(_lenK) ?? minPin;

  static Future<void> setPin(String pin) async {
    final p = await _p;
    final r = Random.secure();
    final salt = base64Url.encode(List<int>.generate(16, (_) => r.nextInt(256)));
    await p.setString(_saltK, salt);
    await p.setString(_hashK, _hash(salt, pin));
    await p.setInt(_lenK, pin.length);
    _changed();
  }

  static Future<bool> verify(String pin) async {
    final p = await _p;
    final salt = p.getString(_saltK), h = p.getString(_hashK);
    if (salt == null || h == null) return false;
    return _hash(salt, pin) == h;
  }

  /// Removing the PIN also removes the disguise, which depends on it.
  static Future<void> clearPin() async {
    final p = await _p;
    await p.remove(_hashK);
    await p.remove(_saltK);
    await p.remove(_lenK);
    await setDisguise(false);
    _changed();
  }

  static Future<bool> disguise() async => (await _p).getBool(_disK) ?? false;

  static Future<void> setDisguise(bool on) async {
    await (await _p).setBool(_disK, on);
    await Native.setDisguise(on);
    await Native.setTaskLabel(on ? 'Calculator' : 'Chary');
    _changed();
  }

  /// Seconds in the background before the app locks again. 0 = immediately.
  static Future<int> relockSeconds() async => (await _p).getInt(_relockK) ?? 30;
  static Future<void> setRelockSeconds(int s) async {
    await (await _p).setInt(_relockK, s);
    _changed();
  }

  /// Minutes to wait for a guardian reply before sending a reminder. 0 = off.
  static Future<int> escalationMinutes() async => (await _p).getInt(_escK) ?? 5;
  static Future<void> setEscalationMinutes(int m) async =>
      (await _p).setInt(_escK, m);
}
