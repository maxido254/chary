import 'dart:async';
import 'package:flutter/material.dart';
import 'consent_screen.dart';
import 'evidence.dart';
import 'evidence_screen.dart';
import 'gate.dart';
import 'guardian_store.dart';
import 'incident_log.dart';
import 'photos.dart';
import 'photos_screen.dart';
import 'incidents_screen.dart';
import 'settings_screen.dart';
import 'sos_controller.dart';
import 'sos_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  BackGuard.install();
  runApp(const CharyApp());
}

class CharyApp extends StatelessWidget {
  const CharyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Chary',
        theme: ThemeData(colorSchemeSeed: Colors.red, useMaterial3: true),
        home: const SplashScreen(),
        // The lock / calculator disguise sits above the Navigator, so it covers every screen.
        builder: (context, child) => Gate(child: child ?? const SizedBox.shrink()),
      );
}


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2200), () async {
      final agreed = await Consent.accepted();
      if (!mounted) return;
      PageRouteBuilder<void> toHome() => PageRouteBuilder(
            pageBuilder: (_, __, ___) => const HomeScreen(),
            transitionsBuilder: (_, a, __, child) =>
                FadeTransition(opacity: a, child: child),
          );
      Navigator.of(context).pushReplacement(
        agreed
            ? toHome()
            : MaterialPageRoute<void>(
                builder: (ctx) => ConsentScreen(
                    onAccepted: () => Navigator.of(ctx).pushReplacement(toHome())),
              ),
      );
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFFD32F2F),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: const [
            Image(image: AssetImage('assets/logo_white.png'), width: 120, height: 120),
            SizedBox(height: 20),
            Text('Chary',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 44,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
            SizedBox(height: 8),
            Text('Yelp for help',
                style: TextStyle(color: Colors.white, fontSize: 20)),
          ]),
        ),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  static const holdSeconds = 3;
  late final AnimationController _hold;
  List<Guardian> _guardians = [];
  final _nameCtrl = TextEditingController();
  Timer? _retryTimer;
  bool _evidence = true;
  bool _photos = true;
  final SosController _sos = SosController.instance;

  @override
  void initState() {
    super.initState();
    _hold = AnimationController(
        vsync: this, duration: const Duration(seconds: holdSeconds))
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) _fire();
      });
    _load();
    SosService.requestPermissions();
    SosService.retryQueue();
    _retryTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      Evidence.syncAll(); // re-send audio parts that failed (no data earlier)
      IncidentLog.sync(); // same for incident log entries
      PhotoLocker.sync(); // and photos
      final ok = await SosService.retryQueue();
      if (ok > 0 && mounted) {
        _sos.setStatus('Delivered $ok queued message(s).');
      }
    });
  }

  Future<void> _load() async {
    _guardians = await GuardianStore.guardians();
    _nameCtrl.text = await GuardianStore.userName();
    _evidence = await GuardianStore.evidenceOn();
    _photos = await GuardianStore.photosOn();
    if (mounted) setState(() {});
  }

  Future<void> _fire() async {
    await _sos.fire();
    if (mounted) _hold.reset();
  }

  String _nameOf(String phone) {
    final g = _guardians.firstWhere((g) => g.phone == phone,
        orElse: () => Guardian('', phone));
    return g.name.isEmpty ? phone : g.name;
  }

  Future<void> _addGuardian() async {
    final n = TextEditingController(), p = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Add guardian'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
          TextField(
              controller: p,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone (+254...)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok == true && p.text.trim().isNotEmpty) {
      _guardians.add(Guardian(n.text.trim(), p.text.trim()));
      await GuardianStore.saveGuardians(_guardians);
      setState(() {});
    }
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _hold.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chary'), actions: [
        IconButton(
          tooltip: 'Evidence',
          icon: const Icon(Icons.folder_special),
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const EvidenceScreen())),
        ),
        IconButton(
          tooltip: 'Photos',
          icon: const Icon(Icons.photo_camera),
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const PhotosScreen())),
        ),
        IconButton(
          tooltip: 'Incident log',
          icon: const Icon(Icons.edit_note),
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const IncidentsScreen())),
        ),
        IconButton(
          tooltip: 'Settings',
          icon: const Icon(Icons.settings),
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
        ),
      ]),
      body: ListenableBuilder(
        listenable: _sos,
        builder: (context, _) => ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: Listener(
            onPointerDown: (_) => _hold.forward(),
            onPointerUp: (_) {
              if (!_sos.sending) _hold.reset();
            },
            onPointerCancel: (_) => _hold.reset(),
            child: AnimatedBuilder(
              animation: _hold,
              builder: (_, __) => Stack(alignment: Alignment.center, children: [
                SizedBox(
                  width: 220,
                  height: 220,
                  child: CircularProgressIndicator(
                      value: _hold.value, strokeWidth: 10, color: Colors.red.shade900),
                ),
                Container(
                  width: 190,
                  height: 190,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                  alignment: Alignment.center,
                  child: const Text('SOS',
                      style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(_sos.status, textAlign: TextAlign.center),
        if (_sos.last != null && _sos.last!.unreached.isNotEmpty)
          Card(
            color: Colors.orange.shade50,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Could not text everyone (no airtime, no SMS bundle or no '
                    'signal). If you have data or Wi-Fi, send on WhatsApp, or call for help.'),
                for (final p in _sos.last!.unreached)
                  TextButton.icon(
                    icon: const Icon(Icons.chat),
                    label: Text('WhatsApp ${_nameOf(p)}'),
                    onPressed: () => SosService.whatsApp(p, _sos.last!.message),
                  ),
              ]),
            ),
          ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: SosService.callEmergency,
          icon: const Icon(Icons.call),
          label: Text('Call emergency (${SosService.emergencyNumber})'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => SosService.call(SosService.helplineNumber),
          icon: const Icon(Icons.support_agent),
          label: Text('GBV helpline ${SosService.helplineNumber} (toll-free)'),
        ),
        if (_sos.alarmOn || _sos.recording || _sos.escalating || _sos.tracking) ...[
          const SizedBox(height: 12),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.black),
            onPressed: () => _sos.setStatus('Press and HOLD to stop.'),
            onLongPress: _sos.stopAll,
            icon: const Icon(Icons.volume_off),
            label: const Text('Hold to stop alarm, recording and location sharing'),
          ),
        ],
        const SizedBox(height: 8),
        // Separate from SOS: the alert is always silent. These two are for scaring someone off or
        // being seen, started and stopped on purpose.
        Row(children: [
          Expanded(
            child: _sos.sirenOn
                ? FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.orange.shade800),
                    onPressed: _sos.toggleSiren,
                    icon: const Icon(Icons.volume_off),
                    label: const Text('Stop siren'),
                  )
                : OutlinedButton.icon(
                    onPressed: _sos.toggleSiren,
                    icon: const Icon(Icons.volume_up),
                    label: const Text('Siren'),
                  ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _sos.flashOn
                ? FilledButton.icon(
                    style: FilledButton.styleFrom(backgroundColor: Colors.orange.shade800),
                    onPressed: _sos.toggleFlash,
                    icon: const Icon(Icons.flashlight_off),
                    label: const Text('Stop flash'),
                  )
                : OutlinedButton.icon(
                    onPressed: _sos.toggleFlash,
                    icon: const Icon(Icons.flashlight_on),
                    label: const Text('Flashlight'),
                  ),
          ),
        ]),
        const SizedBox(height: 4),
        SwitchListTile(
          title: const Text('Record audio evidence on SOS'),
          subtitle: const Text('Saved encrypted on this phone'),
          value: _evidence,
          onChanged: (v) async {
            setState(() => _evidence = v);
            await GuardianStore.saveEvidenceOn(v);
          },
        ),
        SwitchListTile(
          title: const Text('Take photos on SOS (selfie + back)'),
          subtitle: const Text('Silent, no preview. Saved encrypted, behind your PIN'),
          value: _photos,
          onChanged: (v) async {
            setState(() => _photos = v);
            await GuardianStore.savePhotosOn(v);
          },
        ),
        OutlinedButton.icon(
          onPressed: _sos.recording ? null : _sos.recordOnly,
          icon: const Icon(Icons.mic),
          label: const Text('Record evidence now (no alert)'),
        ),
        const Divider(height: 40),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(labelText: 'Your name (shown in the alert)'),
          onChanged: GuardianStore.saveUserName,
        ),
        const SizedBox(height: 16),
        Text('Guardians (${_guardians.length}/${GuardianStore.maxGuardians})',
            style: Theme.of(context).textTheme.titleMedium),
        for (var i = 0; i < _guardians.length; i++)
          ListTile(
            leading: Icon(
                _sos.acked.contains(_guardians[i].phone) ? Icons.check_circle : Icons.shield,
                color: _sos.acked.contains(_guardians[i].phone) ? Colors.green : null),
            title: Text(_guardians[i].name.isEmpty ? _guardians[i].phone : _guardians[i].name),
            subtitle: Text(_sos.acked.contains(_guardians[i].phone)
                ? '${_guardians[i].phone}  (replied)'
                : _guardians[i].phone),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                _guardians.removeAt(i);
                await GuardianStore.saveGuardians(_guardians);
                setState(() {});
              },
            ),
          ),
        if (_guardians.length < GuardianStore.maxGuardians)
          TextButton.icon(
              onPressed: _addGuardian,
              icon: const Icon(Icons.add),
              label: const Text('Add guardian')),
        ]),
      ),
    );
  }
}
