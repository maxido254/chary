import 'dart:async';
import 'package:flutter/material.dart';
import 'guardian_store.dart';
import 'sos_service.dart';

void main() => runApp(const CharyApp());

class CharyApp extends StatelessWidget {
  const CharyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Chary',
        theme: ThemeData(colorSchemeSeed: Colors.red, useMaterial3: true),
        home: const SplashScreen(),
      );
}


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(milliseconds: 2200), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const HomeScreen(),
          transitionsBuilder: (_, a, __, child) =>
              FadeTransition(opacity: a, child: child),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.red,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: const [
            Icon(Icons.shield, color: Colors.white, size: 96),
            SizedBox(height: 20),
            Text('Chary',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 44,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2)),
            SizedBox(height: 8),
            Text('Yelp for help',
                style: TextStyle(color: Colors.white, fontSize: 20)),
          ]),
        ),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  static const holdSeconds = 3;
  late final AnimationController _hold;
  List<Guardian> _guardians = [];
  final _nameCtrl = TextEditingController();
  String _status = 'Hold the button for 3 seconds to send an alert.';
  Timer? _retryTimer;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _hold = AnimationController(
        vsync: this, duration: const Duration(seconds: holdSeconds))
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) _fire();
      });
    _load();
    SosService.requestPermissions();
    _retryTimer = Timer.periodic(const Duration(seconds: 30), (_) async {
      final ok = await SosService.retryQueue();
      if (ok > 0 && mounted) {
        setState(() => _status = 'Delivered $ok queued message(s).');
      }
    });
  }

  Future<void> _load() async {
    _guardians = await GuardianStore.guardians();
    _nameCtrl.text = await GuardianStore.userName();
    if (mounted) setState(() {});
  }

  Future<void> _fire() async {
    if (_sending) return;
    if (_guardians.isEmpty) {
      setState(() => _status = 'Add at least one guardian first.');
      _hold.reset();
      return;
    }
    setState(() {
      _sending = true;
      _status = 'Sending alert...';
    });
    final r = await SosService.trigger();
    if (!mounted) return;
    setState(() {
      _sending = false;
      _status = r.queued == 0
          ? 'Alert sent to ${r.sent} guardian(s).'
          : 'Sent ${r.sent}. ${r.queued} queued, will retry until delivered.';
      if (!r.hasLocation) _status += ' (No GPS fix)';
    });
    _hold.reset();
  }

  Future<void> _addGuardian() async {
    final n = TextEditingController(), p = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Add guardian'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
          TextField(
              controller: p,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone (+254...)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok == true && p.text.trim().isNotEmpty) {
      _guardians.add(Guardian(n.text.trim(), p.text.trim()));
      await GuardianStore.saveGuardians(_guardians);
      setState(() {});
    }
  }

  @override
  void dispose() {
    _retryTimer?.cancel();
    _hold.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chary')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: Listener(
            onPointerDown: (_) => _hold.forward(),
            onPointerUp: (_) {
              if (!_sending) _hold.reset();
            },
            onPointerCancel: (_) => _hold.reset(),
            child: AnimatedBuilder(
              animation: _hold,
              builder: (_, __) => Stack(alignment: Alignment.center, children: [
                SizedBox(
                  width: 220,
                  height: 220,
                  child: CircularProgressIndicator(
                      value: _hold.value, strokeWidth: 10, color: Colors.red.shade900),
                ),
                Container(
                  width: 190,
                  height: 190,
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                  alignment: Alignment.center,
                  child: const Text('SOS',
                      style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.bold)),
                ),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(_status, textAlign: TextAlign.center),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: SosService.callEmergency,
          icon: const Icon(Icons.call),
          label: Text('Call emergency (${SosService.emergencyNumber})'),
        ),
        const Divider(height: 40),
        TextField(
          controller: _nameCtrl,
          decoration: const InputDecoration(labelText: 'Your name (shown in the alert)'),
          onChanged: GuardianStore.saveUserName,
        ),
        const SizedBox(height: 16),
        Text('Guardians (${_guardians.length}/${GuardianStore.maxGuardians})',
            style: Theme.of(context).textTheme.titleMedium),
        for (var i = 0; i < _guardians.length; i++)
          ListTile(
            leading: const Icon(Icons.shield),
            title: Text(_guardians[i].name.isEmpty ? _guardians[i].phone : _guardians[i].name),
            subtitle: Text(_guardians[i].phone),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                _guardians.removeAt(i);
                await GuardianStore.saveGuardians(_guardians);
                setState(() {});
              },
            ),
          ),
        if (_guardians.length < GuardianStore.maxGuardians)
          TextButton.icon(
              onPressed: _addGuardian,
              icon: const Icon(Icons.add),
              label: const Text('Add guardian')),
      ]),
    );
  }
}
