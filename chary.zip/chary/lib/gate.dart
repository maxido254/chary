import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'calc_eval.dart';
import 'lock_store.dart';
import 'native_bridge.dart';
import 'sos_controller.dart';

/// While the lock or countdown is showing, the Back button must not pop the screen underneath.
/// Observers are asked in the order they were added and the first `true` wins, so this one is
/// installed in main() before runApp, ahead of the Navigator's own.
class BackGuard with WidgetsBindingObserver {
  static bool block = false;
  static void install() => WidgetsBinding.instance.addObserver(BackGuard());
  @override
  Future<bool> didPopRoute() async => block;
}

/// Sits above the whole Navigator (see MaterialApp.builder) so the lock, the calculator
/// disguise and the tile countdown cover every screen, including pushed ones.
class Gate extends StatefulWidget {
  final Widget child;
  const Gate({super.key, required this.child});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> with WidgetsBindingObserver {
  bool _ready = false;
  bool _locked = false;
  bool _hasPin = false;
  bool _disguise = false;
  int _relock = 30;
  DateTime? _pausedAt;
  bool _countdown = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    LockStore.changes.addListener(_reload);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    LockStore.changes.removeListener(_reload);
    super.dispose();
  }

  Future<void> _init() async {
    await _load();
    if (!mounted) return;
    setState(() {
      _locked = _hasPin; // always start locked when a PIN exists
      _ready = true;
    });
    Native.setTaskLabel(_disguise ? 'Calculator' : 'Chary');
    _checkTile();
  }

  Future<void> _load() async {
    _hasPin = await LockStore.hasPin();
    _disguise = _hasPin && await LockStore.disguise();
    _relock = await LockStore.relockSeconds();
  }

  /// Settings changed (PIN set, removed, disguise toggled). Never locks the user out mid-edit.
  Future<void> _reload() async {
    await _load();
    if (!mounted) return;
    setState(() {
      if (!_hasPin) _locked = false;
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final at = _pausedAt;
      _pausedAt = null;
      if (_hasPin && at != null && !_locked) {
        if (DateTime.now().difference(at).inSeconds >= _relock) {
          setState(() => _locked = true);
        }
      }
      _checkTile();
    }
  }

  Future<void> _checkTile() async {
    if (await Native.consumeSos() && mounted && !SosController.instance.sending) {
      setState(() => _countdown = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    BackGuard.block = !_ready || _locked || _countdown;
    Widget? overlay;
    if (!_ready) {
      overlay = const ColoredBox(color: Colors.black);
    } else if (_locked) {
      overlay = _disguise
          ? CalculatorScreen(onUnlock: () => setState(() => _locked = false))
          : LockScreen(onUnlock: () => setState(() => _locked = false));
    }
    return Stack(children: [
      Positioned.fill(child: widget.child),
      if (overlay != null) Positioned.fill(child: overlay),
      if (_countdown)
        Positioned.fill(
          child: TileCountdown(
            onCancel: () => setState(() => _countdown = false),
            onDone: () {
              setState(() => _countdown = false);
              SosController.instance.fire();
            },
          ),
        ),
    ]);
  }
}

/// Press and hold for [duration]; calls [onHold] once, with a progress value for drawing.
class HoldDetector extends StatefulWidget {
  final Duration duration;
  final VoidCallback onHold;
  final Widget Function(BuildContext, double progress) builder;
  const HoldDetector({
    super.key,
    this.duration = const Duration(seconds: 3),
    required this.onHold,
    required this.builder,
  });
  @override
  State<HoldDetector> createState() => _HoldDetectorState();
}

class _HoldDetectorState extends State<HoldDetector>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: widget.duration)
      ..addStatusListener((s) {
        if (s == AnimationStatus.completed) {
          HapticFeedback.heavyImpact();
          widget.onHold();
          _c.reset();
        }
      });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Listener(
        onPointerDown: (_) => _c.forward(),
        onPointerUp: (_) => _c.reset(),
        onPointerCancel: (_) => _c.reset(),
        child: AnimatedBuilder(
            animation: _c, builder: (ctx, _) => widget.builder(ctx, _c.value)),
      );
}

// ---------------------------------------------------------------------------
// PIN lock screen
// ---------------------------------------------------------------------------

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const LockScreen({super.key, required this.onUnlock});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String _pin = '';
  int _len = LockStore.minPin;
  int _wrong = 0;
  DateTime? _lockedUntil;
  Timer? _tick;
  String _msg = '';

  @override
  void initState() {
    super.initState();
    LockStore.pinLength().then((l) {
      if (mounted) setState(() => _len = l);
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  bool get _blocked =>
      _lockedUntil != null && DateTime.now().isBefore(_lockedUntil!);

  Future<void> _digit(String d) async {
    if (_blocked || _pin.length >= _len) return;
    setState(() {
      _pin += d;
      _msg = '';
    });
    if (_pin.length < _len) return;
    if (await LockStore.verify(_pin)) {
      widget.onUnlock();
      return;
    }
    _wrong++;
    HapticFeedback.vibrate();
    if (_wrong >= 5) {
      _wrong = 0;
      _lockedUntil = DateTime.now().add(const Duration(seconds: 30));
      _tick?.cancel();
      _tick = Timer.periodic(const Duration(seconds: 1), (t) {
        if (!mounted) return t.cancel();
        if (!_blocked) t.cancel();
        setState(() {});
      });
    }
    setState(() {
      _pin = '';
      _msg = 'Wrong PIN';
    });
  }

  @override
  Widget build(BuildContext context) {
    final sos = SosController.instance;
    final secs = _blocked ? _lockedUntil!.difference(DateTime.now()).inSeconds + 1 : 0;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(children: [
          const Spacer(flex: 2),
          Image.asset('assets/logo.png', width: 64, height: 64),
          const SizedBox(height: 12),
          const Text('Enter PIN', style: TextStyle(fontSize: 22)),
          const SizedBox(height: 20),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var i = 0; i < _len; i++)
              Container(
                width: 14,
                height: 14,
                margin: const EdgeInsets.symmetric(horizontal: 6),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _pin.length ? Colors.black87 : Colors.black12,
                ),
              ),
          ]),
          const SizedBox(height: 12),
          SizedBox(
            height: 24,
            child: Text(_blocked ? 'Too many tries. Wait $secs s' : _msg,
                style: const TextStyle(color: Colors.red)),
          ),
          const Spacer(),
          for (final row in const [
            ['1', '2', '3'],
            ['4', '5', '6'],
            ['7', '8', '9'],
          ])
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (final d in row) _key(d, () => _digit(d)),
            ]),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            _key('', null),
            _key('0', () => _digit('0')),
            _key('⌫', () {
              if (_pin.isNotEmpty) setState(() => _pin = _pin.substring(0, _pin.length - 1));
            }),
          ]),
          const Spacer(),
          // SOS works without the PIN: hold for 3 seconds.
          HoldDetector(
            onHold: () => sos.fire(),
            builder: (_, v) => Stack(alignment: Alignment.center, children: [
              SizedBox(
                  width: 84,
                  height: 84,
                  child: CircularProgressIndicator(
                      value: v, strokeWidth: 6, color: Colors.red.shade900)),
              Container(
                width: 68,
                height: 68,
                decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                alignment: Alignment.center,
                child: const Text('SOS',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ]),
          ),
          const SizedBox(height: 6),
          ListenableBuilder(
            listenable: sos,
            builder: (_, __) => Text(
              sos.active ? 'Alert triggered' : 'Hold SOS for 3 seconds',
              style: const TextStyle(color: Colors.black54, fontSize: 12),
            ),
          ),
          const SizedBox(height: 16),
        ]),
      ),
    );
  }

  Widget _key(String label, VoidCallback? onTap) => Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
          width: 72,
          height: 72,
          child: label.isEmpty
              ? null
              : TextButton(
                  style: TextButton.styleFrom(
                      shape: const CircleBorder(),
                      backgroundColor: Colors.black.withOpacity(0.05)),
                  onPressed: onTap,
                  child: Text(label,
                      style: const TextStyle(fontSize: 26, color: Colors.black87)),
                ),
        ),
      );
}

// ---------------------------------------------------------------------------
// Calculator disguise
// ---------------------------------------------------------------------------

/// Looks and works like a calculator. Type the PIN then "=" to open the app.
/// Hold "%" for 3 seconds to send an SOS (a firm buzz confirms it; nothing is shown).
class CalculatorScreen extends StatefulWidget {
  final VoidCallback onUnlock;
  const CalculatorScreen({super.key, required this.onUnlock});
  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expr = '';

  String get _preview {
    if (_expr.isEmpty) return '';
    final v = CalcEval.evaluate(_expr);
    if (v == null) return '';
    final f = CalcEval.format(v);
    return f == _expr ? '' : f;
  }

  Future<void> _press(String k) async {
    switch (k) {
      case 'AC':
        setState(() => _expr = '');
      case '⌫':
        if (_expr.isNotEmpty) setState(() => _expr = _expr.substring(0, _expr.length - 1));
      case '=':
        if (_expr.isEmpty) return;
        if (RegExp(r'^\d+$').hasMatch(_expr) && await LockStore.verify(_expr)) {
          widget.onUnlock();
          return;
        }
        final v = CalcEval.evaluate(_expr);
        setState(() => _expr = v == null ? 'Error' : CalcEval.format(v));
      case '+' || '−' || '×' || '÷':
        setState(() {
          if (_expr == 'Error') _expr = '';
          if (_expr.isEmpty) {
            if (k == '−') _expr = '−';
            return;
          }
          if (CalcEval.ops.contains(_expr[_expr.length - 1])) {
            if (_expr.length > 1) _expr = _expr.substring(0, _expr.length - 1) + k;
          } else {
            _expr += k;
          }
        });
      default: // digits, '.', '%'
        setState(() {
          if (_expr == 'Error') _expr = '';
          if (_expr.length < 24) _expr += k;
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    const rows = [
      ['AC', '⌫', '%', '÷'],
      ['7', '8', '9', '×'],
      ['4', '5', '6', '−'],
      ['1', '2', '3', '+'],
      ['0', '.', '='],
    ];
    return Scaffold(
      backgroundColor: const Color(0xFF1C1C1E),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: Container(
              alignment: Alignment.bottomRight,
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(_preview, style: const TextStyle(color: Colors.white54, fontSize: 28)),
                const SizedBox(height: 8),
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(_expr.isEmpty ? '0' : _expr,
                      maxLines: 1,
                      style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.w300)),
                ),
              ]),
            ),
          ),
          for (final row in rows)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Row(children: [
                for (final k in row) _calcKey(k, wide: row.length == 3 && k == '0'),
              ]),
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Widget _calcKey(String k, {bool wide = false}) {
    final isOp = const ['÷', '×', '−', '+', '='].contains(k);
    final isTop = const ['AC', '⌫', '%'].contains(k);
    final bg = isOp
        ? const Color(0xFFFF9500)
        : isTop
            ? const Color(0xFFA5A5A5)
            : const Color(0xFF333333);
    final fg = isTop ? Colors.black : Colors.white;
    final btn = Padding(
      padding: const EdgeInsets.all(6),
      child: SizedBox(
        height: 72,
        child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: bg,
              foregroundColor: fg,
              shape: const StadiumBorder()),
          onPressed: () => _press(k),
          child: Text(k, style: TextStyle(fontSize: 28, color: fg)),
        ),
      ),
    );
    final child = k == '%'
        ? HoldDetector(onHold: () => SosController.instance.fire(), builder: (_, __) => btn)
        : btn;
    return Expanded(flex: wide ? 2 : 1, child: child);
  }
}

// ---------------------------------------------------------------------------
// Quick Settings tile: short cancellable countdown, then SOS
// ---------------------------------------------------------------------------

class TileCountdown extends StatefulWidget {
  final VoidCallback onDone;
  final VoidCallback onCancel;
  const TileCountdown({super.key, required this.onDone, required this.onCancel});
  @override
  State<TileCountdown> createState() => _TileCountdownState();
}

class _TileCountdownState extends State<TileCountdown> {
  int _left = 5;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_left <= 1) {
        t.cancel();
        widget.onDone();
      } else {
        setState(() => _left--);
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.red.shade900,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Sending alert in',
                style: TextStyle(color: Colors.white, fontSize: 22)),
            Text('$_left',
                style: const TextStyle(
                    color: Colors.white, fontSize: 96, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: Colors.white, foregroundColor: Colors.red.shade900),
              onPressed: () {
                _t?.cancel();
                widget.onCancel();
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                child: Text('Cancel', style: TextStyle(fontSize: 20)),
              ),
            ),
          ]),
        ),
      );
}
