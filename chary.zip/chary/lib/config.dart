/// App-wide settings. Edit these before building.
class Config {
  /// Default country code used to turn local numbers (07xx...) into international ones.
  static const defaultCountryCode = '254'; // Kenya

  /// Optional internet relay (see relay/README.md). When a guardian cannot be reached
  /// by SMS (no airtime / no SMS bundle) but the phone has data or Wi-Fi, the alert is
  /// POSTed here and the relay sends the SMS for the user. Leave empty to disable.
  static const relayUrl = ''; // e.g. https://chary-relay.yourname.workers.dev
  static const relayKey = ''; // shared secret, must match the relay's APP_KEY

}
