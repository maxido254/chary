import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:geolocator/geolocator.dart';
import 'config.dart';
import 'guardian_store.dart';
import 'lock_store.dart';
import 'sos_service.dart';

/// After an alert, keeps reporting where the phone is until the person stops it with their PIN:
///  - every 2 minutes a point is added to the guardians' link (needs data or Wi-Fi, retried when offline),
///  - every 10 minutes for the first 2 hours an updated location SMS goes to guardians (uses airtime).
/// A foreground notification keeps Android from stopping it while the app is in the background.
class Tracker {
  static const interval = Duration(minutes: 2);
  static const smsEveryTicks = 5; // = every 10 minutes
  static const maxSmsTicks = 60; // = 2 hours
  static const maxDuration = Duration(hours: 48);

  static StreamSubscription<Position>? _sub;
  static Timer? _timer;
  static Timer? _limit;
  static Position? _last;
  static int _ticks = 0;
  static final List<Map<String, dynamic>> _pending = [];

  static bool get active => _timer != null;

  static Future<void> start({
    required String? token,
    required List<Guardian> guardians,
    required String name,
  }) async {
    if (!Platform.isAndroid) return;
    await stop();
    _ticks = 0;
    _pending.clear();
    final disguised = await LockStore.disguise();
    try {
      _sub = Geolocator.getPositionStream(
        locationSettings: AndroidSettings(
          accuracy: LocationAccuracy.high,
          distanceFilter: 0,
          intervalDuration: interval,
          foregroundNotificationConfig: ForegroundNotificationConfig(
            notificationTitle: disguised ? 'Calculator' : 'Chary',
            notificationText: disguised ? 'Running' : 'Sharing your location with your guardians',
            enableWakeLock: true,
            setOngoing: true,
          ),
        ),
      ).listen((p) => _last = p, onError: (_) {});
    } catch (_) {}
    _timer = Timer.periodic(interval, (_) => _tick(token, guardians, name));
    _limit = Timer(maxDuration, stop);
    _tick(token, guardians, name, first: true);
  }

  static Future<void> stop() async {
    _timer?.cancel();
    _timer = null;
    _limit?.cancel();
    _limit = null;
    await _sub?.cancel();
    _sub = null;
    _pending.clear();
  }

  static Future<void> _tick(String? token, List<Guardian> guardians, String name,
      {bool first = false}) async {
    if (!first) _ticks++;
    Position? p;
    try {
      p = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 20),
      );
      _last = p;
    } catch (_) {
      p = _last; // no fresh fix (indoors, GPS off): report the last one we had
    }
    if (p == null) return;

    if (token != null && Config.relayUrl.isNotEmpty) {
      _pending.add({'lat': p.latitude, 'lng': p.longitude, 't': p.timestamp.millisecondsSinceEpoch});
      if (_pending.length > 500) _pending.removeAt(0);
      await _flush(token);
    }
    if (!first && _ticks % smsEveryTicks == 0 && _ticks <= maxSmsTicks) {
      SosService.sendLocationUpdate(guardians, name, p);
    }
  }

  /// Sends points the relay has not confirmed, oldest first. Stops at the first failure (offline).
  static Future<void> _flush(String token) async {
    final base = Config.relayUrl.replaceFirst(RegExp(r'/+$'), '');
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
    try {
      while (_pending.isNotEmpty) {
        final pt = _pending.first;
        final body = utf8.encode(jsonEncode(pt));
        final req = await client.postUrl(Uri.parse('$base/evidence/$token/track'));
        req.headers.set('X-Key', Config.relayKey);
        req.headers.contentType = ContentType.json;
        req.contentLength = body.length;
        req.add(body);
        final res = await req.close().timeout(const Duration(seconds: 15));
        await res.drain();
        if (res.statusCode < 200 || res.statusCode > 299) break;
        if (_pending.isNotEmpty) _pending.removeAt(0);
      }
    } catch (_) {
      // offline: the points stay queued for the next tick
    } finally {
      client.close();
    }
  }
}
