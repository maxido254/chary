import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'photos.dart';

/// Encrypted photo locker. The whole app is behind the PIN, so this is too.
class PhotosScreen extends StatefulWidget {
  const PhotosScreen({super.key});
  @override
  State<PhotosScreen> createState() => _PhotosScreenState();
}

class _PhotosScreenState extends State<PhotosScreen> {
  List<String> _ids = [];
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final l = await PhotoLocker.list();
    if (!mounted) return;
    setState(() {
      _ids = l;
      _loading = false;
    });
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _take(CameraLensDirection dir) async {
    if (_busy) return;
    setState(() => _busy = true);
    final id = await PhotoLocker.capture(dir);
    if (!mounted) return;
    setState(() => _busy = false);
    if (id == null) {
      _toast('Could not take the photo. Check that camera permission is allowed.');
    } else {
      _toast('Saved, encrypted.');
      _refresh();
    }
  }

  Future<void> _open(String id) async {
    final bytes = await PhotoLocker.read(id);
    if (bytes == null || !mounted) return;
    final state = await PhotoLocker.uploadState(id);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        contentPadding: const EdgeInsets.all(8),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Flexible(child: InteractiveViewer(child: Image.memory(bytes))),
          const SizedBox(height: 8),
          Text(
            DateTime.fromMillisecondsSinceEpoch(int.tryParse(id) ?? 0)
                    .toLocal()
                    .toString()
                    .substring(0, 16) +
                (state == 'uploaded'
                    ? '\nAlso saved off the phone'
                    : state == 'waiting'
                        ? '\nWaiting for a connection to upload'
                        : '\nOn this phone only'),
            textAlign: TextAlign.center,
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () async {
                await PhotoLocker.delete(id);
                if (ctx.mounted) Navigator.pop(ctx);
                _refresh();
              },
              child: const Text('Delete')),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Photos')),
      body: Column(children: [
        Card(
          margin: const EdgeInsets.all(12),
          color: Colors.blue.shade50,
          child: const Padding(
            padding: EdgeInsets.all(12),
            child: Text('Photos are encrypted on this phone and only open inside this app, '
                'behind your PIN. A photo of the person, vehicle or injuries can be taken '
                'here without a preview. Photos taken when you send an alert also upload to '
                'your guardians\' link when there is a connection.'),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _busy ? null : () => _take(CameraLensDirection.front),
                icon: const Icon(Icons.face),
                label: const Text('Selfie'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: _busy ? null : () => _take(CameraLensDirection.back),
                icon: const Icon(Icons.photo_camera),
                label: const Text('Back camera'),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _ids.isEmpty
                  ? const Center(child: Text('No photos yet.'))
                  : GridView.builder(
                      padding: const EdgeInsets.all(12),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6),
                      itemCount: _ids.length,
                      itemBuilder: (_, i) => _Thumb(id: _ids[i], onTap: () => _open(_ids[i])),
                    ),
        ),
      ]),
    );
  }
}

class _Thumb extends StatelessWidget {
  final String id;
  final VoidCallback onTap;
  const _Thumb({required this.id, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: FutureBuilder<Uint8List?>(
          future: PhotoLocker.read(id),
          builder: (_, s) => ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: s.data == null
                ? const ColoredBox(color: Colors.black12)
                : Image.memory(s.data!, fit: BoxFit.cover, cacheWidth: 300),
          ),
        ),
      );
}
