import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'evidence.dart';

class EvidenceScreen extends StatefulWidget {
  const EvidenceScreen({super.key});
  @override
  State<EvidenceScreen> createState() => _EvidenceScreenState();
}

class _EvidenceScreenState extends State<EvidenceScreen> {
  List<EvidenceItem> _items = [];
  bool _loading = true;
  String? _playing;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  void dispose() {
    Evidence.stopPlayback();
    super.dispose();
  }

  Future<void> _refresh() async {
    final l = await Evidence.list();
    if (!mounted) return;
    setState(() {
      _items = l;
      _loading = false;
    });
  }

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _togglePlay(EvidenceItem e) async {
    if (_playing == e.id) {
      await Evidence.stopPlayback();
      setState(() => _playing = null);
      return;
    }
    final ok = await Evidence.play(e.id);
    if (!mounted) return;
    setState(() => _playing = ok ? e.id : null);
    if (!ok) _toast('No playable audio in this record.');
  }

  Future<void> _export(EvidenceItem e) async {
    final path = await Evidence.export(e.id);
    _toast(path == null
        ? 'Export failed.'
        : 'Decrypted copy saved at $path. Delete it after sharing.');
  }

  /// Manual backup: opens the share sheet (WhatsApp, email...) with a decrypted copy of the audio.
  Future<void> _share(EvidenceItem e) async {
    final path = await Evidence.prepareShare(e.id);
    if (path == null) {
      _toast('Could not prepare the audio.');
      return;
    }
    final when = e.time.toLocal().toString().substring(0, 16);
    final where = e.mapsLink == null ? '' : '\nLocation: ${e.mapsLink}';
    await Share.shareXFiles([XFile(path, mimeType: 'audio/aac')],
        text: 'Evidence recorded $when.$where');
  }

  String _uploadLabel(EvidenceItem e) {
    switch (e.upload) {
      case 'done':
        return 'Uploaded, guardians can listen';
      case 'partial':
        return 'Uploading... will retry until it all arrives';
      default:
        return Evidence.uploadEnabled ? 'Not uploaded (stays on this phone)' : 'Stored on this phone only';
    }
  }

  Future<void> _delete(EvidenceItem e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete this evidence?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await Evidence.delete(e.id);
      _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Evidence')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No evidence saved yet. Recordings, time and location are '
                      'saved here, encrypted, when you send an alert or tap Record evidence.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: _items.length,
                  itemBuilder: (_, i) {
                    final e = _items[i];
                    final mins = (e.approxSeconds / 60).toStringAsFixed(1);
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      child: Column(children: [
                        ListTile(
                        leading: Icon(e.trigger == 'manual' ? Icons.mic : Icons.warning_amber),
                        title: Text(e.time.toLocal().toString().substring(0, 16)),
                        subtitle: Text(
                          '${e.lat == null ? 'No location' : '${e.lat!.toStringAsFixed(5)}, ${e.lng!.toStringAsFixed(5)}'}'
                          '\nAudio: ${e.audioBytes == 0 ? 'none' : '~$mins min'}'
                          '\n${_uploadLabel(e)}',
                        ),
                        isThreeLine: true,
                        onTap: e.mapsLink == null
                            ? null
                            : () {
                                Clipboard.setData(ClipboardData(text: e.mapsLink!));
                                _toast('Map link copied.');
                              },
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                          child: Wrap(alignment: WrapAlignment.end, children: [
                          if (e.audioBytes > 0)
                            IconButton(
                              icon: Icon(_playing == e.id ? Icons.stop : Icons.play_arrow),
                              onPressed: () => _togglePlay(e),
                            ),
                          if (e.upload == 'partial')
                            IconButton(
                              tooltip: 'Upload now',
                              icon: const Icon(Icons.cloud_upload),
                              onPressed: () async {
                                await Evidence.sync(e.id);
                                _toast('Uploading in the background. Needs data or Wi-Fi.');
                                Future.delayed(const Duration(seconds: 6), () {
                                  if (mounted) _refresh();
                                });
                              },
                            ),
                          if (e.listenLink != null)
                            IconButton(
                              tooltip: 'Copy listen link',
                              icon: const Icon(Icons.link),
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: e.listenLink!));
                                _toast('Listen link copied.');
                              },
                            ),
                          if (e.audioBytes > 0)
                            IconButton(
                                tooltip: 'Share audio',
                                icon: const Icon(Icons.share),
                                onPressed: () => _share(e)),
                          if (e.audioBytes > 0)
                            IconButton(
                                tooltip: 'Save a copy',
                                icon: const Icon(Icons.save_alt),
                                onPressed: () => _export(e)),
                          IconButton(
                              icon: const Icon(Icons.delete_outline), onPressed: () => _delete(e)),
                        ]),
                        ),
                      ]),
                    );
                  },
                ),
    );
  }
}
