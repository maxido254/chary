import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'evidence.dart';
import 'guardian_store.dart';
import 'lock_store.dart';
import 'native_bridge.dart';
import 'photos.dart';
import 'sos_service.dart';
import 'tracker.dart';

/// One place that owns the alert, so the home screen, the lock screens and the
/// Quick Settings tile all trigger and stop it the same way.
class SosController extends ChangeNotifier {
  SosController._();
  static final SosController instance = SosController._();

  static const idleStatus = 'Hold the button for 3 seconds to send a silent alert.';
  static const maxReminders = 3;

  bool sending = false;
  bool sirenOn = false;
  bool flashOn = false;
  bool recording = false;
  String status = idleStatus;
  SosResult? last;

  /// Guardian phones (as stored) that have replied since the alert started.
  final Set<String> acked = {};
  int reminders = 0;

  Timer? _reminderTimer;
  Timer? _ackPoll;
  int _startMs = 0;
  List<Guardian> _guardians = [];
  String _name = '';

  bool get escalating => _reminderTimer != null;
  bool tracking = false;

  /// Siren or flashlight running (these are separate buttons, never started by SOS).
  bool get alarmOn => sirenOn || flashOn;

  bool get active => sending || alarmOn || recording || escalating || tracking;

  void setStatus(String s) {
    status = s;
    notifyListeners();
  }

  /// Send the alert. Returns false if nothing was sent (no guardians, or already sending).
  Future<bool> fire() async {
    if (sending) return false;
    final guardians = await GuardianStore.guardians();
    if (guardians.isEmpty) {
      setStatus('Add at least one guardian first.');
      return false;
    }
    final ev = await GuardianStore.evidenceOn();
    _name = await GuardianStore.userName();
    _guardians = guardians;
    _stopEscalation();

    sending = true;
    status = 'Sending alert...';
    recording = ev;
    acked.clear();
    reminders = 0;
    notifyListeners();

    await Native.clearAcks();
    _startMs = DateTime.now().millisecondsSinceEpoch;
    final token = Evidence.newAlertToken(); // one link per alert: audio, photos and the location trail

    // ONE press starts everything at the same moment, none of it waits for the SMS:
    //  - selfie + back photo (each uploads as soon as it is taken)
    //  - location sharing every 2 minutes
    //  - audio recording and its live upload (starts inside SosService.trigger, before any SMS)
    //  - the SMS alert itself
    final photoFut = (await GuardianStore.photosOn())
        ? PhotoLocker.captureBoth(trigger: 'sos', token: token)
        : Future.value(<String>[]);
    final trackFut = Tracker.start(token: token, guardians: guardians, name: _name);
    final r = await SosService.trigger(evidence: ev);

    sending = false;
    last = r;
    status = r.queued == 0
        ? 'Alert sent to ${r.sent} guardian(s).'
        : 'Sent ${r.sent}. ${r.queued} saved: they send by themselves when airtime or signal returns, even if the app is closed.';
    if (r.viaRelay > 0) status += ' ${r.viaRelay} sent over the internet.';
    if (!r.hasLocation) status += ' (No GPS fix)';
    notifyListeners();

    await photoFut;
    await trackFut;
    await _startEscalation();
    tracking = Tracker.active;
    if (tracking) status += ' Your location is shared every 2 minutes until you stop it.';
    notifyListeners();
    return true;
  }

  /// The siren and the flashlight are their own buttons: tap to start, tap again to stop.
  /// An alert (SOS) is always silent.
  Future<void> toggleSiren() async {
    sirenOn = !sirenOn;
    notifyListeners();
    sirenOn ? await SosService.startSiren() : await SosService.stopSiren();
  }

  Future<void> toggleFlash() async {
    flashOn = !flashOn;
    notifyListeners();
    flashOn ? await SosService.startFlash() : await SosService.stopFlash();
  }

  /// Start a recording without sending any alert.
  Future<void> recordOnly() async {
    final id = await Evidence.start(
        pos: await Evidence.quickPosition(), trigger: 'manual');
    recording = id != null;
    status = id != null
        ? 'Recording evidence. Hold the black button to stop.'
        : 'Could not start recording.';
    notifyListeners();
  }

  /// Stops the siren, the recording and any pending reminders.
  Future<void> stopAll() async {
    _stopEscalation();
    await Tracker.stop();
    tracking = false;
    await SosService.stopAlarm();
    await Evidence.stop();
    Evidence.syncAll();
    sirenOn = false;
    flashOn = false;
    recording = false;
    status = 'Stopped.';
    notifyListeners();
  }

  // ---------- guardian replies + reminders ----------

  Future<void> _startEscalation() async {
    if (!Platform.isAndroid) return;
    final mins = await LockStore.escalationMinutes();
    if (mins <= 0) return;
    _reminderTimer = Timer(Duration(minutes: mins), _remind);
    _ackPoll = Timer.periodic(const Duration(seconds: 10), (_) => refreshAcks());
    notifyListeners();
  }

  void _stopEscalation() {
    _reminderTimer?.cancel();
    _reminderTimer = null;
    _ackPoll?.cancel();
    _ackPoll = null;
  }

  /// Reads who has texted back since the alert started.
  Future<void> refreshAcks() async {
    if (_startMs == 0) return;
    final entries = await Native.acks();
    var changed = false;
    for (final g in _guardians) {
      if (acked.contains(g.phone)) continue;
      final replied = entries.any(
          (e) => e.millis >= _startMs && SosService.sameNumber(e.number, g.phone));
      if (replied) {
        acked.add(g.phone);
        changed = true;
      }
    }
    if (changed) {
      if (acked.length >= _guardians.length) {
        _stopEscalation();
        status = 'Everyone has replied. No more reminders will be sent.';
      } else {
        status = '${acked.length} of ${_guardians.length} guardians replied.';
      }
      notifyListeners();
    }
  }

  Future<void> _remind() async {
    await refreshAcks();
    if (_reminderTimer == null) return; // stopped, or everyone replied meanwhile
    final pending = _guardians.where((g) => !acked.contains(g.phone)).toList();
    if (pending.isEmpty) {
      _stopEscalation();
      return;
    }
    reminders++;
    await SosService.sendReminder(pending, _name, reminders,
        audioLink: last?.audioLink);
    if (_reminderTimer == null) return; // stopped while sending
    if (reminders >= maxReminders) {
      _stopEscalation();
      status = 'No reply from ${pending.length}. Reminder $reminders sent, no more will follow.';
    } else {
      final mins = await LockStore.escalationMinutes();
      _reminderTimer = Timer(Duration(minutes: mins > 0 ? mins : 5), _remind);
      status = 'No reply from ${pending.length}. Reminder $reminders sent.';
    }
    notifyListeners();
  }
}
