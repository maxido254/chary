import 'dart:convert';
import 'native_bridge.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Guardian {
  final String name;
  final String phone;
  Guardian(this.name, this.phone);
  Map<String, String> toJson() => {'name': name, 'phone': phone};
  factory Guardian.fromJson(Map<String, dynamic> j) =>
      Guardian(j['name'] as String, j['phone'] as String);
}

/// Everything is stored locally on the device. No server involved.
class GuardianStore {
  static const _gKey = 'guardians';
  static const _nameKey = 'user_name';
  static const _queueKey = 'pending_queue';
  static const maxGuardians = 5;
  static const _loudKey = 'loud_alarm';
  static const _evKey = 'evidence_on';

  static Future<bool> evidenceOn() async =>
      (await SharedPreferences.getInstance()).getBool(_evKey) ?? true;

  static Future<void> saveEvidenceOn(bool v) async =>
      (await SharedPreferences.getInstance()).setBool(_evKey, v);

  static Future<bool> photosOn() async =>
      (await SharedPreferences.getInstance()).getBool('photos_on') ?? true;

  static Future<void> savePhotosOn(bool v) async =>
      (await SharedPreferences.getInstance()).setBool('photos_on', v);

  static Future<bool> loudAlarm() async =>
      (await SharedPreferences.getInstance()).getBool(_loudKey) ?? false; // silent by default

  static Future<void> saveLoudAlarm(bool v) async =>
      (await SharedPreferences.getInstance()).setBool(_loudKey, v);

  static Future<List<Guardian>> guardians() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_gKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Guardian.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  static Future<void> saveGuardians(List<Guardian> list) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_gKey, jsonEncode(list.map((g) => g.toJson()).toList()));
  }

  static Future<String> userName() async =>
      (await SharedPreferences.getInstance()).getString(_nameKey) ?? '';

  static Future<void> saveUserName(String n) async =>
      (await SharedPreferences.getInstance()).setString(_nameKey, n);

  /// Queue of {phone, text} messages that failed to send.
  static Future<List<Map<String, String>>> queue() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_queueKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => Map<String, String>.from(e as Map))
        .toList();
  }

  static Future<void> saveQueue(List<Map<String, String>> q) async {
    await (await SharedPreferences.getInstance()).setString(_queueKey, jsonEncode(q));
    // Waiting alerts are re-sent in the background until airtime or signal returns.
    await Native.scheduleRetry(q.isNotEmpty);
  }
}
