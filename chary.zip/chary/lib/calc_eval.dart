/// Tiny arithmetic evaluator for the calculator disguise.
/// Grammar:  expr := term (('+'|'−') term)*   term := factor (('×'|'÷') factor)*
///           factor := ('−'|'+') factor | number '%'*
class CalcEval {
  static const ops = ['+', '−', '×', '÷'];

  /// Returns null if the expression is incomplete or invalid (e.g. "5+", "1÷0").
  static double? evaluate(String src) {
    final p = _Parser(src);
    try {
      final v = p.expr();
      if (!p.atEnd) return null;
      if (v.isNaN || v.isInfinite) return null;
      return v;
    } catch (_) {
      return null;
    }
  }

  static String format(double v) {
    if (v == v.roundToDouble() && v.abs() < 1e15) return v.toInt().toString();
    var s = v.toStringAsFixed(8);
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
    return s == '-0' ? '0' : s;
  }
}

class _Parser {
  final String s;
  int i = 0;
  _Parser(this.s);

  bool get atEnd => i >= s.length;
  String get cur => s[i];

  double expr() {
    var v = term();
    while (!atEnd && (cur == '+' || cur == '−')) {
      final op = cur;
      i++;
      final r = term();
      v = op == '+' ? v + r : v - r;
    }
    return v;
  }

  double term() {
    var v = factor();
    while (!atEnd && (cur == '×' || cur == '÷')) {
      final op = cur;
      i++;
      final r = factor();
      if (op == '÷' && r == 0) throw const FormatException('div0');
      v = op == '×' ? v * r : v / r;
    }
    return v;
  }

  double factor() {
    if (atEnd) throw const FormatException('eof');
    if (cur == '−') {
      i++;
      return -factor();
    }
    if (cur == '+') {
      i++;
      return factor();
    }
    final start = i;
    while (!atEnd && (RegExp(r'[0-9.]').hasMatch(cur))) {
      i++;
    }
    if (start == i) throw const FormatException('num');
    var v = double.parse(s.substring(start, i));
    while (!atEnd && cur == '%') {
      v /= 100;
      i++;
    }
    return v;
  }
}
