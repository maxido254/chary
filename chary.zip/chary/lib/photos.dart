import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

/// Photos taken with the front (selfie) and back camera, encrypted on the phone with the same
/// hardware-backed key as the audio evidence and only readable inside the app (behind the PIN).
/// Photos taken during an alert are also uploaded to the relay when there is a connection.
class PhotoLocker {
  static const _ch = MethodChannel('chary/sms');
  static const _metaKey = 'photo_meta'; // id -> {t: token, u: uploaded}
  static bool _busy = false;

  static Future<Map<String, dynamic>> _meta() async {
    final raw = (await SharedPreferences.getInstance()).getString(_metaKey);
    if (raw == null) return {};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {};
    }
  }

  static Future<void> _saveMeta(Map<String, dynamic> m) async =>
      (await SharedPreferences.getInstance()).setString(_metaKey, jsonEncode(m));

  static bool get uploadEnabled => Config.relayUrl.isNotEmpty;

  /// One photo from each camera, front first. Returns the ids that were saved.
  /// With a [token], each photo is queued for upload to the alert's link the moment it is saved.
  static Future<List<String>> captureBoth({String trigger = 'manual', String? token}) async {
    final ids = <String>[];
    for (final dir in [CameraLensDirection.front, CameraLensDirection.back]) {
      final id = await capture(dir);
      if (id != null) {
        ids.add(id);
        attach([id], token); // not awaited: the next camera starts while this one uploads
      }
    }
    return ids;
  }

  /// Silent: no preview, no flash. The camera file the plugin writes is deleted at once and the
  /// picture is kept only in encrypted form.
  static Future<String?> capture(CameraLensDirection dir) async {
    if (!Platform.isAndroid || _busy) return null;
    _busy = true;
    CameraController? c;
    try {
      final cams = (await availableCameras()).where((x) => x.lensDirection == dir).toList();
      if (cams.isEmpty) return null;
      c = CameraController(cams.first, ResolutionPreset.medium,
          enableAudio: false, imageFormatGroup: ImageFormatGroup.jpeg);
      await c.initialize();
      try {
        await c.setFlashMode(FlashMode.off);
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 700)); // let exposure settle
      final x = await c.takePicture();
      final Uint8List bytes = await x.readAsBytes();
      try {
        await File(x.path).delete();
      } catch (_) {}
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      final ok = await _ch.invokeMethod<bool>('savePhoto', {'id': id, 'bytes': bytes}) ?? false;
      return ok ? id : null;
    } catch (_) {
      return null; // camera busy, permission missing, or app in the background
    } finally {
      _busy = false;
      try {
        await c?.dispose();
      } catch (_) {}
    }
  }

  /// Marks photos as belonging to an alert's evidence link, then uploads them.
  static Future<void> attach(List<String> ids, String? token) async {
    if (token == null || ids.isEmpty) return;
    final m = await _meta();
    for (final id in ids) {
      m[id] = {'t': token, 'u': false};
    }
    await _saveMeta(m);
    await sync();
  }

  static bool _syncing = false;

  /// Uploads photos not yet confirmed by the relay. Safe to call often; does nothing offline.
  static Future<void> sync() async {
    if (!uploadEnabled || _syncing || !Platform.isAndroid) return;
    _syncing = true;
    try {
      for (var round = 0; round < 4; round++) {
        if (!await _syncOnce()) break;
      }
    } finally {
      _syncing = false;
    }
  }

  /// One pass over the photos still to upload. True if it uploaded something and should look again.
  static Future<bool> _syncOnce() async {
    var progressed = false;
    {
      final m = await _meta();
      final todo = m.entries
          .where((e) => (e.value as Map)['t'] != null && (e.value as Map)['u'] != true)
          .map((e) => e.key)
          .toList();
      if (todo.isEmpty) return false;
      final base = Config.relayUrl.replaceFirst(RegExp(r'/+$'), '');
      final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
      try {
        for (final id in todo) {
          final bytes = await read(id);
          if (bytes == null) continue;
          try {
            final token = (m[id] as Map)['t'] as String;
            final req = await client.postUrl(Uri.parse('$base/evidence/$token/photo/$id'));
            req.headers.set('X-Key', Config.relayKey);
            req.headers.contentType = ContentType('image', 'jpeg');
            req.contentLength = bytes.length;
            req.add(bytes);
            final res = await req.close().timeout(const Duration(seconds: 30));
            await res.drain();
            if (res.statusCode < 200 || res.statusCode > 299) break;
            final fresh = await _meta();
            if (fresh[id] != null) {
              fresh[id] = {'t': token, 'u': true};
              await _saveMeta(fresh);
              progressed = true;
            }
          } catch (_) {
            break; // offline: try again later
          }
        }
      } finally {
        client.close();
      }
    }
    return progressed;
  }

  static Future<List<String>> list() async {
    if (!Platform.isAndroid) return [];
    try {
      return (await _ch.invokeMethod<List<dynamic>>('listPhotos') ?? const [])
          .map((e) => e.toString())
          .toList();
    } catch (_) {
      return [];
    }
  }

  /// Decrypted JPEG bytes (in memory only).
  static Future<Uint8List?> read(String id) async {
    try {
      return await _ch.invokeMethod<Uint8List>('readPhoto', {'id': id});
    } catch (_) {
      return null;
    }
  }

  /// 'none' (stays on the phone), 'waiting' or 'uploaded'.
  static Future<String> uploadState(String id) async {
    final e = (await _meta())[id];
    if (e == null || (e as Map)['t'] == null) return 'none';
    return e['u'] == true ? 'uploaded' : 'waiting';
  }

  static Future<void> delete(String id) async {
    try {
      await _ch.invokeMethod('deletePhoto', {'id': id});
    } catch (_) {}
    final m = await _meta();
    if (m.remove(id) != null) await _saveMeta(m);
  }
}
