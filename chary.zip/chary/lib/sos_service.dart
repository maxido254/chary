import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';
import 'evidence.dart';
import 'guardian_store.dart';

class SosResult {
  final int sent;
  final int queued;
  final bool hasLocation;
  final List<String> unreached; // guardians SMS (and relay) could not reach
  final String message;
  final int viaRelay;
  final String? audioLink;
  SosResult(this.sent, this.queued, this.hasLocation,
      {this.unreached = const [],
      this.message = '',
      this.viaRelay = 0,
      this.audioLink});
}

class SosService {
  static const _ch = MethodChannel('chary/sms');

  /// Local emergency number. 112 works in Kenya and most of the world.
  static const emergencyNumber = '112';

  /// Kenya national GBV helpline, toll-free, 24/7.
  static const helplineNumber = '1195';

  static Future<void> requestPermissions() async {
    await [
      Permission.locationWhenInUse,
      if (Platform.isAndroid) ...[
        Permission.sms,
        Permission.microphone,
        Permission.notification,
      ],
    ].request();
  }

  // ---------- number helpers ----------

  static String _digits(String p) => p.replaceAll(RegExp(r'[^\d]'), '');

  /// International digits without '+', e.g. 0712345678 -> 254712345678.
  static String intlNumber(String phone) {
    final cc = Config.defaultCountryCode;
    final d = _digits(phone);
    if (phone.trim().startsWith('+')) return d;
    if (d.startsWith('00')) return d.substring(2);
    if (d.startsWith('0')) return '$cc${d.substring(1)}';
    if (d.length <= 9) return '$cc$d';
    return d;
  }

  /// Local format, e.g. 254712345678 -> 0712345678.
  static String localNumber(String phone) {
    final cc = Config.defaultCountryCode;
    final d = intlNumber(phone);
    return d.startsWith(cc) ? '0${d.substring(cc.length)}' : d;
  }

  // ---------- location ----------

  static Future<Position?> _lastKnown() async {
    try {
      return await Geolocator.getLastKnownPosition();
    } catch (_) {
      return null;
    }
  }

  static Future<Position?> _fresh() async {
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 8),
      );
    } catch (_) {
      return null;
    }
  }

  static String buildMessage(String name, Position? pos,
      {bool updated = false, String? audioLink}) {
    final who = name.isEmpty ? 'Someone you know' : name;
    final time = DateTime.now().toLocal().toString().substring(0, 16);
    final loc = pos == null
        ? 'Location unavailable.'
        : 'Location: https://maps.google.com/?q=${pos.latitude},${pos.longitude}';
    if (updated) return 'UPDATED LOCATION from $who. $loc Time: $time.';
    return 'EMERGENCY: $who needs help and is reporting a sexual assault. '
        '$loc Time: $time. '
        '${audioLink == null ? '' : 'Listen live: $audioLink '}'
        'Please call them or contact emergency services now. '
        'Reply to this text so they know you have seen it.';
  }

  /// Sent when a guardian has not replied after the reminder interval.
  static String buildReminder(String name, Position? pos, int round,
      {String? audioLink}) {
    final who = name.isEmpty ? 'Someone you know' : name;
    final time = DateTime.now().toLocal().toString().substring(0, 16);
    final loc = pos == null
        ? 'Location unavailable.'
        : 'Location: https://maps.google.com/?q=${pos.latitude},${pos.longitude}';
    return 'REMINDER $round: $who still needs help and we have not heard from you. '
        '$loc Time: $time. ${audioLink == null ? '' : 'Listen: $audioLink '}'
        'Please reply to this text, then call them or emergency services.';
  }

  /// True if two phone numbers are the same person (compares the last 9 digits).
  static bool sameNumber(String a, String b) {
    final x = _digits(a), y = _digits(b);
    if (x.isEmpty || y.isEmpty) return false;
    final n = x.length < y.length ? x.length : y.length;
    if (n < 7) return x == y;
    final k = n < 9 ? n : 9;
    return x.substring(x.length - k) == y.substring(y.length - k);
  }

  /// Reminder to guardians who have not replied. Same delivery order as the first alert:
  /// SMS, then relay, then queue for retry. Returns how many were sent.
  static Future<int> sendReminder(List<Guardian> targets, String name, int round,
      {String? audioLink}) async {
    if (!Platform.isAndroid || targets.isEmpty) return 0;
    final pos = await _fresh() ?? await _lastKnown();
    final text = buildReminder(name, pos, round, audioLink: audioLink);
    int ok = 0;
    final failed = <String>[];
    for (final g in targets) {
      if (await _sendAndroid(g.phone, text)) {
        ok++;
      } else {
        failed.add(g.phone);
      }
    }
    if (failed.isNotEmpty) {
      if (await _relay(failed, text)) {
        ok += failed.length;
      } else {
        final q = await GuardianStore.queue();
        await GuardianStore.saveQueue(
            [...q, for (final p in failed) {'phone': p, 'text': text}]);
      }
    }
    return ok;
  }

  // ---------- the one-press action ----------

  /// Delivery order for each guardian:
  ///  1. SMS (needs cellular signal + airtime/SMS bundle)
  ///  2. Internet relay (needs data or Wi-Fi, no airtime), if configured
  ///  3. Queue the SMS and retry; the UI offers WhatsApp and call buttons
  static Future<SosResult> trigger({bool alarm = true, bool evidence = true}) async {
    final guardians = await GuardianStore.guardians();
    final name = await GuardianStore.userName();
    if (alarm) await startAlarm();

    final last = await _lastKnown();
    final evId = evidence ? await Evidence.start(pos: last) : null;
    final msg1 = buildMessage(name, last,
        audioLink: evId == null ? null : Evidence.linkFor(evId));

    int sent = 0;
    bool hasLoc = last != null;
    int viaRelay = 0;
    var unreached = <String>[];
    final failed = <Map<String, String>>[];

    if (Platform.isAndroid) {
      Future<int> sendAll(String text, List<Guardian> targets) async {
        final res = await Future.wait(targets.map((g) => _sendAndroid(g.phone, text)));
        int ok = 0;
        for (var i = 0; i < res.length; i++) {
          if (res[i]) {
            ok++;
          } else {
            failed.add({'phone': targets[i].phone, 'text': text});
          }
        }
        return ok;
      }

      sent = await sendAll(msg1, guardians);
      final smsFailed = failed.map((m) => m['phone']!).toSet();
      unreached = smsFailed.toList();
      final relayed = <String>[];

      if (unreached.isNotEmpty) {
        if (await _relay(unreached, msg1)) {
          relayed.addAll(unreached);
          sent += relayed.length;
          failed.removeWhere((m) => smsFailed.contains(m['phone']));
          unreached = [];
        }
      }
      viaRelay = relayed.length;

      final fresh = await _fresh();
      if (fresh != null) {
        hasLoc = true;
        if (evId != null) await Evidence.updateLocation(evId, fresh);
        final moved = last == null ||
            Geolocator.distanceBetween(last.latitude, last.longitude,
                    fresh.latitude, fresh.longitude) >
                50;
        if (moved) {
          final upd = buildMessage(name, fresh, updated: true);
          await sendAll(upd, guardians.where((g) => !smsFailed.contains(g.phone)).toList());
          if (relayed.isNotEmpty) await _relay(relayed, upd);
        }
      }
    } else {
      // iOS cannot send SMS silently. Open the composer pre-filled; user taps Send once.
      final pos = await _fresh() ?? last;
      hasLoc = pos != null;
      final nums = guardians.map((g) => g.phone).join(',');
      final body = Uri.encodeComponent(buildMessage(name, pos));
      if (await launchUrl(Uri.parse('sms:$nums?body=$body'))) {
        sent = guardians.length;
      }
    }

    if (failed.isNotEmpty) {
      final q = await GuardianStore.queue();
      await GuardianStore.saveQueue([...q, ...failed]);
    }
    return SosResult(sent, failed.length, hasLoc,
        unreached: unreached,
        message: msg1,
        viaRelay: viaRelay,
        audioLink: evId == null ? null : Evidence.linkFor(evId));
  }

  // ---------- channels ----------

  static Future<bool> _sendAndroid(String phone, String text) async {
    try {
      return await _ch
              .invokeMethod<bool>('sendSms', {'number': phone, 'text': text})
              .timeout(const Duration(seconds: 25), onTimeout: () => false) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Internet relay: works with data or Wi-Fi and zero airtime.
  static Future<bool> _relay(List<String> phones, String text) async {
    if (Config.relayUrl.isEmpty) return false;
    try {
      final c = HttpClient()..connectionTimeout = const Duration(seconds: 10);
      final req = await c.postUrl(Uri.parse(Config.relayUrl));
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode({
        'key': Config.relayKey,
        'to': phones.map((p) => '+${intlNumber(p)}').toList(),
        'message': text,
      }));
      final resp = await req.close().timeout(const Duration(seconds: 15));
      await resp.drain<void>();
      c.close();
      return resp.statusCode >= 200 && resp.statusCode < 300;
    } catch (_) {
      return false;
    }
  }

  /// Retry queued SMS (no internet needed, only signal and airtime).
  static Future<int> retryQueue() async {
    if (!Platform.isAndroid) return 0;
    final q = await GuardianStore.queue();
    if (q.isEmpty) return 0;
    final remaining = <Map<String, String>>[];
    int ok = 0;
    for (final m in q) {
      if (await _sendAndroid(m['phone']!, m['text']!)) {
        ok++;
      } else {
        remaining.add(m);
      }
    }
    await GuardianStore.saveQueue(remaining);
    return ok;
  }

  /// Opens WhatsApp with the alert pre-filled. Works over data or Wi-Fi, no airtime.
  /// The person taps Send once.
  static Future<void> whatsApp(String phone, String text) async => launchUrl(
        Uri.parse('https://wa.me/${intlNumber(phone)}?text=${Uri.encodeComponent(text)}'),
        mode: LaunchMode.externalApplication,
      );

  static Future<void> startAlarm() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('startAlarm');
    } catch (_) {}
  }

  static Future<void> stopAlarm() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('stopAlarm');
    } catch (_) {}
  }

  /// Emergency calls work without airtime on most networks.
  static Future<void> call(String number) async => launchUrl(Uri.parse('tel:$number'));
  static Future<void> callEmergency() async => call(emergencyNumber);
}
