import 'dart:io';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'guardian_store.dart';

class SosResult {
  final int sent;
  final int queued;
  final bool hasLocation;
  SosResult(this.sent, this.queued, this.hasLocation);
}

class SosService {
  static const _sms = MethodChannel('chary/sms');

  /// Local emergency number. 112 works in Kenya and most of the world; change as needed.
  static const emergencyNumber = '112';

  static Future<void> requestPermissions() async {
    await [Permission.locationWhenInUse, if (Platform.isAndroid) Permission.sms]
        .request();
  }

  static Future<Position?> _location() async {
    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
      ).timeout(const Duration(seconds: 6));
    } catch (_) {
      // GPS slow or unavailable: fall back to last known position.
      try {
        return await Geolocator.getLastKnownPosition();
      } catch (_) {
        return null;
      }
    }
  }

  static String buildMessage(String name, Position? pos) {
    final who = name.isEmpty ? 'Someone you know' : name;
    final time = DateTime.now().toLocal().toString().substring(0, 16);
    final loc = pos == null
        ? 'Location unavailable.'
        : 'Location: https://maps.google.com/?q=${pos.latitude},${pos.longitude}';
    return 'EMERGENCY: $who needs help and is reporting a sexual assault. '
        '$loc Time: $time. Please call them or contact emergency services now.';
  }

  /// The one-press action.
  static Future<SosResult> trigger() async {
    final guardians = await GuardianStore.guardians();
    final name = await GuardianStore.userName();
    final pos = await _location();
    final text = buildMessage(name, pos);

    int sent = 0;
    final failed = <Map<String, String>>[];

    if (Platform.isAndroid) {
      for (final g in guardians) {
        if (await _sendAndroid(g.phone, text)) {
          sent++;
        } else {
          failed.add({'phone': g.phone, 'text': text});
        }
      }
    } else {
      // iOS cannot send SMS silently. Open the composer pre-filled; user taps Send once.
      final nums = guardians.map((g) => g.phone).join(',');
      final uri = Uri.parse('sms:$nums?body=${Uri.encodeComponent(text)}');
      if (await launchUrl(uri)) sent = guardians.length;
    }

    if (failed.isNotEmpty) {
      final q = await GuardianStore.queue();
      await GuardianStore.saveQueue([...q, ...failed]);
    }
    return SosResult(sent, failed.length, pos != null);
  }

  static Future<bool> _sendAndroid(String phone, String text) async {
    try {
      return await _sms.invokeMethod<bool>(
              'sendSms', {'number': phone, 'text': text}) ??
          false;
    } catch (_) {
      return false;
    }
  }

  /// Retry queued messages. Call periodically while the app is open.
  static Future<int> retryQueue() async {
    if (!Platform.isAndroid) return 0;
    final q = await GuardianStore.queue();
    if (q.isEmpty) return 0;
    final remaining = <Map<String, String>>[];
    int ok = 0;
    for (final m in q) {
      if (await _sendAndroid(m['phone']!, m['text']!)) {
        ok++;
      } else {
        remaining.add(m);
      }
    }
    await GuardianStore.saveQueue(remaining);
    return ok;
  }

  static Future<void> callEmergency() async =>
      launchUrl(Uri.parse('tel:$emergencyNumber'));
}
