import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'config.dart';

class EvidenceItem {
  final String id;
  final DateTime time;
  final double? lat;
  final double? lng;
  final String trigger;
  final int audioBytes;
  /// 'none' (not uploading), 'partial' (some parts still to send) or 'done'.
  final String upload;
  final String token;
  EvidenceItem(this.id, this.time, this.lat, this.lng, this.trigger, this.audioBytes,
      {this.upload = 'none', this.token = ''});

  /// Link a guardian can open to listen, if this recording is being uploaded.
  String? get listenLink => token.isEmpty ? null : Evidence.linkForToken(token);

  String? get mapsLink =>
      lat == null ? null : 'https://maps.google.com/?q=$lat,$lng';

  /// Audio is 64 kbps = about 8000 bytes per second.
  int get approxSeconds => (audioBytes / 8000).round();
}

/// Evidence capture: timestamp + location + audio, encrypted on the phone (Android).
class Evidence {
  static const _ch = MethodChannel('chary/sms');
  static final Map<String, String> _times = {};
  static final Map<String, String> _tokens = {};

  /// Token of the most recent alert's recording (photos taken for that alert use it).
  static String? currentToken;

  static bool get uploadEnabled => Config.relayUrl.isNotEmpty;

  static String? linkForToken(String token) => uploadEnabled
      ? '${Config.relayUrl.replaceFirst(RegExp(r'/+$'), '')}/e/$token'
      : null;

  /// Link for a recording started in this session (null if it is not being uploaded).
  static String? linkFor(String id) {
    final t = _tokens[id];
    return t == null ? null : linkForToken(t);
  }

  /// Starts a new alert link (null if there is no relay). Everything from one alert shares it:
  /// audio, photos and the location trail.
  static String? newAlertToken() {
    currentToken = uploadEnabled ? _newToken() : null;
    return currentToken;
  }

  /// The link guardians open for the current alert.
  static String? alertLink() => currentToken == null ? null : linkForToken(currentToken!);

  static String _newToken() {
    final r = Random.secure();
    return List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
  }

  static Map<String, dynamic> _meta(String time, Position? p, String trigger) =>
      {'time': time, 'lat': p?.latitude, 'lng': p?.longitude, 'trigger': trigger};

  static Future<Position?> quickPosition() async {
    try {
      return await Geolocator.getLastKnownPosition();
    } catch (_) {
      return null;
    }
  }

  static Future<String?> start({Position? pos, String trigger = 'sos'}) async {
    if (!Platform.isAndroid) return null;
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final time = DateTime.now().toIso8601String();
    // Only alerts are uploaded (a guardian gets the link). "Record now" stays on the phone.
    final token = (uploadEnabled && trigger == 'sos') ? currentToken : null;
    try {
      if (uploadEnabled) {
        await _ch.invokeMethod(
            'setUploadConfig', {'url': Config.relayUrl, 'key': Config.relayKey});
      }
      await _ch.invokeMethod('startEvidence',
          {'id': id, 'meta': jsonEncode(_meta(time, pos, trigger)), 'token': token});
      _times[id] = time;
      if (token != null) _tokens[id] = token;
      return id;
    } catch (_) {
      return null;
    }
  }

  static Future<void> updateLocation(String id, Position pos,
      {String trigger = 'sos'}) async {
    final time = _times[id];
    if (time == null) return;
    try {
      await _ch.invokeMethod('updateEvidenceMeta',
          {'id': id, 'meta': jsonEncode(_meta(time, pos, trigger))});
    } catch (_) {}
  }

  static Future<void> stop() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('stopEvidence');
    } catch (_) {}
  }

  static Future<List<EvidenceItem>> list() async {
    if (!Platform.isAndroid) return [];
    try {
      final raw = await _ch.invokeMethod<List<dynamic>>('listEvidence') ?? [];
      return raw.map((e) {
        final m = Map<String, dynamic>.from(e as Map);
        Map<String, dynamic> meta = {};
        try {
          meta = jsonDecode(m['meta'] as String) as Map<String, dynamic>;
        } catch (_) {}
        final id = m['id'] as String;
        return EvidenceItem(
          id,
          DateTime.tryParse(meta['time'] as String? ?? '') ??
              DateTime.fromMillisecondsSinceEpoch(int.tryParse(id) ?? 0),
          (meta['lat'] as num?)?.toDouble(),
          (meta['lng'] as num?)?.toDouble(),
          (meta['trigger'] as String?) ?? 'sos',
          (m['audioBytes'] as num).toInt(),
          upload: (m['upload'] as String?) ?? 'none',
          token: (m['token'] as String?) ?? '',
        );
      }).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<bool> play(String id) async =>
      (await _ch.invokeMethod<bool>('playEvidence', {'id': id})) ?? false;

  static Future<void> stopPlayback() async {
    try {
      await _ch.invokeMethod('stopPlayback');
    } catch (_) {}
  }

  /// Writes a DECRYPTED copy to the app's external folder and returns its path.
  static Future<String?> export(String id) async =>
      _ch.invokeMethod<String>('exportEvidence', {'id': id});

  /// Re-sends any audio parts that did not get through (needs data or Wi-Fi). Safe to call often.
  static Future<void> syncAll() async {
    if (!Platform.isAndroid || !uploadEnabled) return;
    try {
      await _ch.invokeMethod('setUploadConfig', {'url': Config.relayUrl, 'key': Config.relayKey});
      await _ch.invokeMethod('syncEvidence');
    } catch (_) {}
  }

  static Future<void> sync(String id) async {
    try {
      await _ch.invokeMethod('setUploadConfig', {'url': Config.relayUrl, 'key': Config.relayKey});
      await _ch.invokeMethod('syncEvidence', {'id': id});
    } catch (_) {}
  }

  /// Decrypted copy in the cache folder, for the share sheet. Null if there is no audio.
  static Future<String?> prepareShare(String id) async {
    try {
      return await _ch.invokeMethod<String>('prepareShare', {'id': id});
    } catch (_) {
      return null;
    }
  }

  static Future<void> delete(String id) async =>
      _ch.invokeMethod('deleteEvidence', {'id': id});
}
