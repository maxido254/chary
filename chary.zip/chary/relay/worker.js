// Cloudflare Worker: sends SMS for people who have data/Wi-Fi but no airtime.
// Uses Africa's Talking (Kenyan SMS API). Deploy steps are in relay/README.md.
//
// Also stores evidence audio (R2 bucket bound as EVIDENCE) and serves a listen page to guardians.
//
// Secrets to set:  APP_KEY, AT_USERNAME, AT_API_KEY
// Optional var:    AT_URL (defaults to the live API; use the sandbox URL for testing)
// R2 binding:      EVIDENCE  (see wrangler.toml)

const MAX_PART_BYTES = 256 * 1024;   // app sends ~96 KB parts
const MAX_PHOTO_BYTES = 3 * 1024 * 1024; // phone sends reduced-size JPEGs
const MAX_PART_SEQ = 20000;          // ~66 hours of audio, far above the app's 3 hour limit
const TOKEN_RE = /^[a-f0-9]{32}$/;   // random per recording, made by the phone: the secret in the link

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (path.startsWith("/evidence/")) return upload(request, env, path);
    if (path.startsWith("/e/")) return view(request, env, ctx, path);
    if (path.startsWith("/incident/")) return incidentUpload(request, env, path);
    if (path.startsWith("/log/")) return incidentLog(request, env, path);

    if (request.method !== "POST") return new Response("ok");

    let body;
    try { body = await request.json(); } catch { return new Response("bad request", { status: 400 }); }

    if (!env.APP_KEY || body.key !== env.APP_KEY) return new Response("forbidden", { status: 403 });

    const to = (Array.isArray(body.to) ? body.to : [])
      .slice(0, 5)                      // never more than 5 recipients per call
      .map(normalize)
      .filter(Boolean);
    const message = String(body.message || "").slice(0, 600);
    if (!to.length || !message) return new Response("bad request", { status: 400 });

    const form = new URLSearchParams({ username: env.AT_USERNAME, to: to.join(","), message });
    const r = await fetch(env.AT_URL || "https://api.africastalking.com/version1/messaging", {
      method: "POST",
      headers: {
        apiKey: env.AT_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form,
    });
    return new Response(await r.text(), { status: r.status });
  },
};

function normalize(n) {
  n = String(n).replace(/[^\d+]/g, "");
  if (n.startsWith("+")) return n;
  if (n.startsWith("0")) return "+254" + n.slice(1);
  if (n.startsWith("254")) return "+" + n;
  return null;
}

// ---------- evidence upload (phone -> R2) ----------
// POST /evidence/<token>/<seq>   raw audio bytes (AAC) for part <seq>, header X-Key
// POST /evidence/<token>/meta    small JSON {time, lat, lng}
async function upload(request, env, path) {
  if (request.method !== "POST") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("evidence storage not configured", { status: 501 });
  if (!env.APP_KEY || request.headers.get("X-Key") !== env.APP_KEY) return new Response("forbidden", { status: 403 });

  // location trail: POST /evidence/<token>/track  {lat, lng}. The key carries the point, so no reads are needed to draw the trail.
  const tm = path.match(/^\/evidence\/([a-f0-9]{32})\/track$/);
  if (tm) {
    const tlen = Number(request.headers.get("content-length") || 0);
    if (!tlen || tlen > 512) return new Response("bad size", { status: 413 });
    let j;
    try { j = JSON.parse(await request.text()); } catch { return new Response("bad request", { status: 400 }); }
    if (!Number.isFinite(j.lat) || !Number.isFinite(j.lng) || Math.abs(j.lat) > 90 || Math.abs(j.lng) > 180)
      return new Response("bad request", { status: 400 });
    const at = Number.isFinite(j.t) && j.t > 1.6e12 && j.t < 4e12 ? Math.floor(j.t) : Date.now(); // phone's fix time
    await env.EVIDENCE.put(`${tm[1]}/trk/${at}_${j.lat.toFixed(6)}_${j.lng.toFixed(6)}`, "");
    return new Response("ok");
  }

  const pm = path.match(/^\/evidence\/([a-f0-9]{32})\/photo\/(\d{10,16})$/);
  if (pm) {
    const plen = Number(request.headers.get("content-length") || 0);
    if (!plen || plen > MAX_PHOTO_BYTES) return new Response("bad size", { status: 413 });
    const img = await request.arrayBuffer();
    if (img.byteLength > MAX_PHOTO_BYTES) return new Response("bad size", { status: 413 });
    const b = new Uint8Array(img);
    if (!(b[0] === 0xff && b[1] === 0xd8)) return new Response("jpeg only", { status: 415 }); // JPEG magic bytes
    await env.EVIDENCE.put(`${pm[1]}/photo/${pm[2]}.jpg`, img);
    return new Response("ok");
  }

  const m = path.match(/^\/evidence\/([a-f0-9]{32})\/(meta|\d{1,5})$/);
  if (!m) return new Response("bad request", { status: 400 });
  const [, token, what] = m;
  const len = Number(request.headers.get("content-length") || 0);

  if (what === "meta") {
    if (!len || len > 2048) return new Response("bad request", { status: 400 });
    let j;
    try { j = JSON.parse(await request.text()); } catch { return new Response("bad request", { status: 400 }); }
    const clean = {
      time: typeof j.time === "string" ? j.time.slice(0, 40) : null,
      lat: Number.isFinite(j.lat) ? j.lat : null,
      lng: Number.isFinite(j.lng) ? j.lng : null,
    };
    await env.EVIDENCE.put(`${token}/meta.json`, JSON.stringify(clean));
    return new Response("ok");
  }

  const seq = Number(what);
  if (seq > MAX_PART_SEQ) return new Response("bad request", { status: 400 });
  if (!len || len > MAX_PART_BYTES) return new Response("bad size", { status: 413 });
  const bytes = await request.arrayBuffer();
  if (bytes.byteLength > MAX_PART_BYTES) return new Response("bad size", { status: 413 });
  await env.EVIDENCE.put(`${token}/${String(seq).padStart(6, "0")}`, bytes); // same seq again just overwrites
  return new Response("ok");
}

// ---------- listening (guardian -> browser) ----------
// GET /e/<token>        a small page with a player, the time and a map link
// GET /e/<token>/audio  all parts joined, in order
async function view(request, env, ctx, path) {
  if (request.method !== "GET") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("not found", { status: 404 });
  const m = path.match(/^\/e\/([a-f0-9]{32})(\/audio|\/photo\/\d{10,16})?$/);
  if (!m || !TOKEN_RE.test(m[1])) return new Response("not found", { status: 404 });
  const token = m[1];
  const headers = { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" };

  if (m[2] && m[2].startsWith("/photo/")) {
    const o = await env.EVIDENCE.get(`${token}${m[2]}.jpg`);
    if (!o) return new Response("not found", { status: 404 });
    return new Response(o.body, { headers: { ...headers, "Content-Type": "image/jpeg" } });
  }
  const keys = await partKeys(env, token);

  if (m[2] === "/audio") {
    if (!keys.length) return new Response("not found", { status: 404 });
    const { readable, writable } = new TransformStream();
    ctx.waitUntil((async () => {
      try {
        for (const k of keys) {
          const o = await env.EVIDENCE.get(k);
          if (o) await o.body.pipeTo(writable, { preventClose: true });
        }
      } finally {
        await writable.close().catch(() => {});
      }
    })());
    return new Response(readable, { headers: { ...headers, "Content-Type": "audio/aac" } });
  }

  const metaObj = await env.EVIDENCE.get(`${token}/meta.json`);
  const photoIds = await photoList(env, token);
  const trail = await trackPoints(env, token);
  const nothingYet = !keys.length && !metaObj && !photoIds.length && !trail.length;
  const fmt = (ms) => new Date(ms).toLocaleString("en-GB", { timeZone: "Africa/Nairobi", dateStyle: "short", timeStyle: "short" });
  const trailHtml = trail.length
    ? `<h3>Last known location</h3>
<p><b>${esc(fmt(trail[0].t))}</b> (Nairobi time) <a href="https://maps.google.com/?q=${trail[0].lat},${trail[0].lng}">Open on map</a></p>
<details><summary>Earlier points (${trail.length})</summary><ol>${trail.slice(1, 40).map((p) =>
  `<li>${esc(fmt(p.t))} <a href="https://maps.google.com/?q=${p.lat},${p.lng}">map</a></li>`).join("")}</ol></details>`
    : "";
  let meta = {};
  if (metaObj) { try { meta = await metaObj.json(); } catch {} }
  const time = esc(meta.time || "");
  const map = Number.isFinite(meta.lat) && Number.isFinite(meta.lng)
    ? `<p><a href="https://maps.google.com/?q=${meta.lat},${meta.lng}">Open location on map</a></p>` : "";
  const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Emergency alert</title>
<body style="font-family:sans-serif;max-width:32em;margin:2em auto;padding:0 1em">
<h2>Emergency alert</h2>
<p>From a person who sent an emergency alert. Location, photos and audio appear here as they arrive. Reload to see the latest. ${time ? "Started: " + time + "." : ""}</p>
${map}
${trailHtml}
${photoIds.map((id) => `<p><img src="/e/${token}/photo/${id}" style="width:100%;border-radius:6px"></p>`).join("")}
${nothingYet ? "<p><b>Waiting for the first data.</b> The alert was just sent. Location, photos and audio appear here as soon as the phone has a connection. Reload in a minute.</p>" : ""}
${keys.length ? `<audio controls preload="auto" style="width:100%" src="/e/${token}/audio"></audio>
<p>${keys.length} part(s) so far. If the recording is still going, reload this page to hear the latest.</p>`
  : "<p>No audio has arrived yet. Reload in a minute.</p>"}
<p>If someone is in danger, call the emergency number (112 in Kenya).</p>`;
  return new Response(html, { headers: { ...headers, "Content-Type": "text/html; charset=utf-8" } });
}

// newest first: [{t, lat, lng}]
async function trackPoints(env, token) {
  const pts = [];
  let cursor;
  do {
    const r = await env.EVIDENCE.list({ prefix: `${token}/trk/`, cursor });
    for (const o of r.objects) {
      const mm = o.key.match(/\/trk\/(\d+)_(-?[\d.]+)_(-?[\d.]+)$/);
      if (mm) pts.push({ t: Number(mm[1]), lat: Number(mm[2]), lng: Number(mm[3]) });
    }
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return pts.sort((a, b) => b.t - a.t).slice(0, 200);
}

async function photoList(env, token) {
  const ids = [];
  let cursor;
  do {
    const r = await env.EVIDENCE.list({ prefix: `${token}/photo/`, cursor });
    for (const o of r.objects) {
      const mm = o.key.match(/\/photo\/(\d{10,16})\.jpg$/);
      if (mm) ids.push(mm[1]);
    }
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return ids.sort().slice(0, 50);
}

async function partKeys(env, token) {
  const keys = [];
  let cursor;
  do {
    const r = await env.EVIDENCE.list({ prefix: `${token}/`, cursor });
    for (const o of r.objects) if (/\/\d{6}$/.test(o.key)) keys.push(o.key);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return keys.sort();
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- stalking / incident log (phone -> R2 -> guardians) ----------
// POST /incident/<token>/<id>   JSON {time, lat, lng, text}, header X-Key. Same id again overwrites.
// GET  /log/<token>             timeline page, oldest first, safe to hand to the police
async function incidentUpload(request, env, path) {
  if (request.method !== "POST") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("evidence storage not configured", { status: 501 });
  if (!env.APP_KEY || request.headers.get("X-Key") !== env.APP_KEY) return new Response("forbidden", { status: 403 });
  const m = path.match(/^\/incident\/([a-f0-9]{32})\/(\d{10,16})$/);
  if (!m) return new Response("bad request", { status: 400 });
  const len = Number(request.headers.get("content-length") || 0);
  if (!len || len > 8192) return new Response("bad size", { status: 413 });
  let j;
  try { j = JSON.parse(await request.text()); } catch { return new Response("bad request", { status: 400 }); }
  const clean = {
    time: typeof j.time === "string" ? j.time.slice(0, 40) : null,
    lat: Number.isFinite(j.lat) ? j.lat : null,
    lng: Number.isFinite(j.lng) ? j.lng : null,
    text: typeof j.text === "string" ? j.text.slice(0, 2000) : "",
  };
  await env.EVIDENCE.put(`${m[1]}/inc/${m[2]}.json`, JSON.stringify(clean));
  return new Response("ok");
}

async function incidentLog(request, env, path) {
  if (request.method !== "GET") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("not found", { status: 404 });
  const m = path.match(/^\/log\/([a-f0-9]{32})$/);
  if (!m) return new Response("not found", { status: 404 });
  const token = m[1];
  const keys = [];
  let cursor;
  do {
    const r = await env.EVIDENCE.list({ prefix: `${token}/inc/`, cursor });
    for (const o of r.objects) keys.push(o.key);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  if (!keys.length) return new Response("not found", { status: 404 });
  keys.sort();
  const rows = [];
  for (const k of keys.slice(0, 500)) {
    const o = await env.EVIDENCE.get(k);
    if (!o) continue;
    let e = {};
    try { e = await o.json(); } catch {}
    const map = Number.isFinite(e.lat) && Number.isFinite(e.lng)
      ? ` <a href="https://maps.google.com/?q=${e.lat},${e.lng}">map</a>` : "";
    rows.push(`<li><b>${esc(e.time || "")}</b>${map}<br>${esc(e.text || "").replace(/\n/g, "<br>")}</li>`);
  }
  const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Incident log</title>
<body style="font-family:sans-serif;max-width:36em;margin:2em auto;padding:0 1em">
<h2>Incident log (${rows.length})</h2>
<p>Written by the person themselves, in the order it happened. Keep a copy, and take it with you if you report to the police. Ask for an OB (Occurrence Book) number.</p>
<ol>${rows.join("")}</ol>`;
  return new Response(html, { headers: {
    "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" } });
}
