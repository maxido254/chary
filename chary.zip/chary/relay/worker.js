// Cloudflare Worker: sends SMS for people who have data/Wi-Fi but no airtime.
// Uses Africa's Talking (Kenyan SMS API). Deploy steps are in relay/README.md.
//
// Also stores evidence audio (R2 bucket bound as EVIDENCE) and serves a listen page to guardians.
//
// Secrets to set:  APP_KEY, AT_USERNAME, AT_API_KEY
// Optional var:    AT_URL (defaults to the live API; use the sandbox URL for testing)
// R2 binding:      EVIDENCE  (see wrangler.toml)

const MAX_PART_BYTES = 256 * 1024;   // app sends ~96 KB parts
const MAX_PART_SEQ = 20000;          // ~66 hours of audio, far above the app's 3 hour limit
const TOKEN_RE = /^[a-f0-9]{32}$/;   // random per recording, made by the phone: the secret in the link

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    if (path.startsWith("/evidence/")) return upload(request, env, path);
    if (path.startsWith("/e/")) return view(request, env, ctx, path);

    if (request.method !== "POST") return new Response("ok");

    let body;
    try { body = await request.json(); } catch { return new Response("bad request", { status: 400 }); }

    if (!env.APP_KEY || body.key !== env.APP_KEY) return new Response("forbidden", { status: 403 });

    const to = (Array.isArray(body.to) ? body.to : [])
      .slice(0, 5)                      // never more than 5 recipients per call
      .map(normalize)
      .filter(Boolean);
    const message = String(body.message || "").slice(0, 600);
    if (!to.length || !message) return new Response("bad request", { status: 400 });

    const form = new URLSearchParams({ username: env.AT_USERNAME, to: to.join(","), message });
    const r = await fetch(env.AT_URL || "https://api.africastalking.com/version1/messaging", {
      method: "POST",
      headers: {
        apiKey: env.AT_API_KEY,
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: form,
    });
    return new Response(await r.text(), { status: r.status });
  },
};

function normalize(n) {
  n = String(n).replace(/[^\d+]/g, "");
  if (n.startsWith("+")) return n;
  if (n.startsWith("0")) return "+254" + n.slice(1);
  if (n.startsWith("254")) return "+" + n;
  return null;
}

// ---------- evidence upload (phone -> R2) ----------
// POST /evidence/<token>/<seq>   raw audio bytes (AAC) for part <seq>, header X-Key
// POST /evidence/<token>/meta    small JSON {time, lat, lng}
async function upload(request, env, path) {
  if (request.method !== "POST") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("evidence storage not configured", { status: 501 });
  if (!env.APP_KEY || request.headers.get("X-Key") !== env.APP_KEY) return new Response("forbidden", { status: 403 });

  const m = path.match(/^\/evidence\/([a-f0-9]{32})\/(meta|\d{1,5})$/);
  if (!m) return new Response("bad request", { status: 400 });
  const [, token, what] = m;
  const len = Number(request.headers.get("content-length") || 0);

  if (what === "meta") {
    if (!len || len > 2048) return new Response("bad request", { status: 400 });
    let j;
    try { j = JSON.parse(await request.text()); } catch { return new Response("bad request", { status: 400 }); }
    const clean = {
      time: typeof j.time === "string" ? j.time.slice(0, 40) : null,
      lat: Number.isFinite(j.lat) ? j.lat : null,
      lng: Number.isFinite(j.lng) ? j.lng : null,
    };
    await env.EVIDENCE.put(`${token}/meta.json`, JSON.stringify(clean));
    return new Response("ok");
  }

  const seq = Number(what);
  if (seq > MAX_PART_SEQ) return new Response("bad request", { status: 400 });
  if (!len || len > MAX_PART_BYTES) return new Response("bad size", { status: 413 });
  const bytes = await request.arrayBuffer();
  if (bytes.byteLength > MAX_PART_BYTES) return new Response("bad size", { status: 413 });
  await env.EVIDENCE.put(`${token}/${String(seq).padStart(6, "0")}`, bytes); // same seq again just overwrites
  return new Response("ok");
}

// ---------- listening (guardian -> browser) ----------
// GET /e/<token>        a small page with a player, the time and a map link
// GET /e/<token>/audio  all parts joined, in order
async function view(request, env, ctx, path) {
  if (request.method !== "GET") return new Response("method not allowed", { status: 405 });
  if (!env.EVIDENCE) return new Response("not found", { status: 404 });
  const m = path.match(/^\/e\/([a-f0-9]{32})(\/audio)?$/);
  if (!m || !TOKEN_RE.test(m[1])) return new Response("not found", { status: 404 });
  const token = m[1];
  const keys = await partKeys(env, token);
  const headers = { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "X-Robots-Tag": "noindex" };

  if (m[2]) {
    if (!keys.length) return new Response("not found", { status: 404 });
    const { readable, writable } = new TransformStream();
    ctx.waitUntil((async () => {
      try {
        for (const k of keys) {
          const o = await env.EVIDENCE.get(k);
          if (o) await o.body.pipeTo(writable, { preventClose: true });
        }
      } finally {
        await writable.close().catch(() => {});
      }
    })());
    return new Response(readable, { headers: { ...headers, "Content-Type": "audio/aac" } });
  }

  const metaObj = await env.EVIDENCE.get(`${token}/meta.json`);
  if (!keys.length && !metaObj) return new Response("not found", { status: 404 });
  let meta = {};
  if (metaObj) { try { meta = await metaObj.json(); } catch {} }
  const time = esc(meta.time || "");
  const map = Number.isFinite(meta.lat) && Number.isFinite(meta.lng)
    ? `<p><a href="https://maps.google.com/?q=${meta.lat},${meta.lng}">Open location on map</a></p>` : "";
  const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Emergency audio</title>
<body style="font-family:sans-serif;max-width:32em;margin:2em auto;padding:0 1em">
<h2>Emergency audio</h2>
<p>Recorded from a person who sent an emergency alert. ${time ? "Started: " + time + "." : ""}</p>
${map}
${keys.length ? `<audio controls preload="auto" style="width:100%" src="/e/${token}/audio"></audio>
<p>${keys.length} part(s) so far. If the recording is still going, reload this page to hear the latest.</p>`
  : "<p>No audio has arrived yet. Reload in a minute.</p>"}
<p>If someone is in danger, call the emergency number (112 in Kenya).</p>`;
  return new Response(html, { headers: { ...headers, "Content-Type": "text/html; charset=utf-8" } });
}

async function partKeys(env, token) {
  const keys = [];
  let cursor;
  do {
    const r = await env.EVIDENCE.list({ prefix: `${token}/`, cursor });
    for (const o of r.objects) if (/\/\d{6}$/.test(o.key)) keys.push(o.key);
    cursor = r.truncated ? r.cursor : undefined;
  } while (cursor);
  return keys.sort();
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
