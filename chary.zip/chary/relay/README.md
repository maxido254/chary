# Chary relay (optional, for people with data/Wi-Fi but no airtime)

Without this, a phone with no airtime cannot text anyone. With it, Chary sends the alert
over the internet to this relay, and the relay sends the SMS from YOUR Africa's Talking
account, so the person in danger pays nothing.

## Deploy (free Cloudflare Workers tier + Africa's Talking account)
1. Create an Africa's Talking account, buy a little SMS credit, copy your username and API key.
   (Test first with the sandbox: set AT_URL to https://api.sandbox.africastalking.com/version1/messaging)
2. Install Wrangler and create a worker from worker.js:
   npm i -g wrangler && wrangler login
   wrangler init chary-relay   (replace the generated script with worker.js)
3. Set secrets:
   wrangler secret put APP_KEY       # any long random string
   wrangler secret put AT_USERNAME
   wrangler secret put AT_API_KEY
4. wrangler deploy  -> you get https://chary-relay.<you>.workers.dev
5. Put that URL and APP_KEY into lib/config.dart (relayUrl, relayKey) and rebuild the app.

## Know the risks
- Whoever extracts APP_KEY from the APK can send SMS on your credit. Set a daily spending
  limit in Africa's Talking, and add rate limiting in Cloudflare.
- Alert text and phone numbers pass through Cloudflare and Africa's Talking. Say so in your privacy policy.
- Every SMS costs you money. Budget for it.

## Evidence upload (optional, same relay)
While recording, the app uploads the audio to your R2 bucket in ~12 second parts and the alert SMS
includes a link guardians can open to listen (works in any phone browser, no app or login).
Parts that fail (no data) are retried automatically until they get through.

Extra setup:
1. `wrangler r2 bucket create chary-evidence` (the included `wrangler.toml` already binds it as `EVIDENCE`).
2. In the Cloudflare dashboard, add an R2 lifecycle rule to delete objects after e.g. 30 days.
3. `wrangler deploy` again. No new secrets: it uses the same `APP_KEY`.

Know the risks
- The link is the only protection: 128 random bits, never listed, but anyone a guardian forwards it to can listen. Audio is uploaded as plain AAC over HTTPS and is readable by you as the relay owner. Say so in your privacy policy.
- Storage is small (about 0.5 MB per minute), but cap R2 usage in Cloudflare and rate-limit the worker as above.
