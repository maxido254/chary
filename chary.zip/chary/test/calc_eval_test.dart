import 'package:chary/calc_eval.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('precedence and basic arithmetic', () {
    expect(CalcEval.evaluate('12+3×4'), 24);
    expect(CalcEval.evaluate('10−4−3'), 3);
    expect(CalcEval.evaluate('8÷4÷2'), 1);
    expect(CalcEval.evaluate('1.5+1.5'), 3);
  });

  test('unary minus and percent', () {
    expect(CalcEval.evaluate('−5+8'), 3);
    expect(CalcEval.evaluate('50%'), 0.5);
    expect(CalcEval.evaluate('200×10%'), 20);
  });

  test('invalid input returns null', () {
    expect(CalcEval.evaluate('5+'), isNull);
    expect(CalcEval.evaluate('1÷0'), isNull);
    expect(CalcEval.evaluate('×3'), isNull);
    expect(CalcEval.evaluate('1..2'), isNull);
  });

  test('format', () {
    expect(CalcEval.format(24), '24');
    expect(CalcEval.format(0.5), '0.5');
    expect(CalcEval.format(1 / 3), '0.33333333');
  });

  test('sameNumber-style PIN strings are plain numbers, not errors', () {
    // The calculator checks the PIN before evaluating, so "1234" never needs evaluating,
    // but it must still be a valid expression if it does not match.
    expect(CalcEval.evaluate('1234'), 1234);
  });
}
