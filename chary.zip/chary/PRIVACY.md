# Chary privacy policy

*Template: fill in the [brackets], host it at a public web address, and link to it from your app listing and from the app. Have a lawyer or a data-protection adviser read it before you publish widely.*

Last updated: [DATE]. Operator: [YOUR NAME OR ORGANISATION], [EMAIL ADDRESS].

## What Chary is
Chary is a personal safety app. It is for use on **your own phone**. It must never be installed on another person's phone or used to watch another person.

## What the app collects, and only when
Nothing is collected in the background. These things happen only after **you** press SOS or use the matching button:

| Data | When | Where it goes |
|---|---|---|
| Your location | After you press SOS, every 2 minutes until you stop it | Text messages to the guardians you chose; and, if a relay is set up, to a private link your guardians receive |
| Audio recording | After you press SOS (switchable) | Encrypted on your phone; and, if a relay is set up, to the same private link |
| Photos (selfie and back camera) | After you press SOS (switchable) or when you take one in the app | Encrypted on your phone; and, if a relay is set up, to the same private link |
| Incident log entries | When you write one | On your phone; and, if a relay is set up, to a private link you can share |
| Which guardian numbers texted you back | After an alert | Stays on your phone. The text of their reply is never read |
| Guardian names and phone numbers, your name | When you enter them | Stay on your phone; guardians' numbers are sent to the relay only to deliver an alert by internet if the text message fails |

## Who can see it
- Only the guardians you choose, through a private link containing a long random code. Anyone who has the link can open it, so share it only with people you trust.
- The relay operator ([YOUR NAME]) can technically access what is stored on the relay. The audio and photos on the relay are not end-to-end encrypted.
- We do not sell data, show adverts, or use analytics or trackers.

## How long we keep it
Data on the relay is deleted automatically after [30] days. Data on your phone stays until you delete it in the app or uninstall the app.

## Your choices
- You can switch off audio and photos, and stop location sharing, at any time. Block-uninstall and the calculator disguise are off until you turn them on.
- To have your data removed from the relay, email [EMAIL ADDRESS] with the link you shared.

## Permissions and why
SMS (send the alert; see who replied), location (alert and 2-minute updates), microphone and camera (evidence), notifications and foreground service (keep location sharing running), device administrator (optional, to block uninstall), boot (resume sending saved alerts after a restart), internet (relay).

## Law
If you run the relay you are handling personal information. In Kenya the Data Protection Act, 2019 may require you to register with the Office of the Data Protection Commissioner. Check with the ODPC.

## Children
Chary is not directed at children under 18.

## Contact
[EMAIL ADDRESS]
