package com.chary.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/**
 * Records WHO texted the phone, never what they wrote. The app uses this to see that a
 * guardian replied to an alert, which stops further reminders to that guardian.
 */
class AckReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        try {
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val set = HashSet(prefs.getStringSet(KEY, emptySet()) ?: emptySet())
            val now = System.currentTimeMillis()
            for (m in msgs) {
                val from = m.originatingAddress ?: continue
                set.add("$from|$now")
            }
            // keep the list small
            val trimmed = set.sortedByDescending { it.substringAfter('|').toLongOrNull() ?: 0L }.take(50)
            prefs.edit().putStringSet(KEY, trimmed.toSet()).apply()
        } catch (_: Exception) {}
    }

    companion object {
        const val PREFS = "chary_ack"
        const val KEY = "acks"
    }
}
