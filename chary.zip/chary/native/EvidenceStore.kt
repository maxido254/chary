package com.example.chary

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Evidence is encrypted with AES-256-GCM using a key held in the Android Keystore
 * (it never leaves secure hardware/OS storage). Data is written as small independent
 * encrypted chunks, so a recording stays readable even if the phone dies mid-recording.
 * File format per chunk: [int length][12-byte IV][ciphertext + tag].
 */
object EvidenceStore {
    private const val ALIAS = "chary_evidence_key"
    private var cached: SecretKey? = null

    @Synchronized
    private fun key(): SecretKey {
        cached?.let { return it }
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey(ALIAS, null) as? SecretKey
        if (existing != null) { cached = existing; return existing }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        val k = kg.generateKey()
        cached = k
        return k
    }

    fun dir(ctx: Context): File = File(ctx.filesDir, "evidence").also { it.mkdirs() }
    fun metaFile(ctx: Context, id: String) = File(dir(ctx), "$id.meta")
    fun audioFile(ctx: Context, id: String) = File(dir(ctx), "$id.aud")

    fun writeChunk(out: OutputStream, data: ByteArray, len: Int = data.size) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val iv = c.iv
        val ct = c.doFinal(data, 0, len)
        val dos = DataOutputStream(out)
        dos.writeInt(iv.size + ct.size)
        dos.write(iv)
        dos.write(ct)
        dos.flush()
    }

    /** Decrypts every readable chunk; a damaged or half-written tail is ignored. */
    fun decryptTo(src: File, out: OutputStream) {
        if (!src.exists()) return
        DataInputStream(BufferedInputStream(FileInputStream(src))).use { din ->
            val k = key()
            while (true) {
                val total = try { din.readInt() } catch (_: EOFException) { break }
                if (total < 28 || total > 1_000_000) break
                val buf = ByteArray(total)
                try { din.readFully(buf) } catch (_: EOFException) { break }
                try {
                    val c = Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, buf.copyOfRange(0, 12)))
                    out.write(c.doFinal(buf, 12, total - 12))
                } catch (_: Exception) { break }
            }
        }
    }

    fun writeMeta(ctx: Context, id: String, json: String) {
        FileOutputStream(metaFile(ctx, id)).use { writeChunk(it, json.toByteArray(Charsets.UTF_8)) }
    }

    fun readMeta(ctx: Context, id: String): String {
        val bo = ByteArrayOutputStream()
        decryptTo(metaFile(ctx, id), bo)
        return bo.toString("UTF-8")
    }

    fun delete(ctx: Context, id: String) {
        metaFile(ctx, id).delete()
        audioFile(ctx, id).delete()
    }
}
