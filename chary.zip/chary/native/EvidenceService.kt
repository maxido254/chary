package com.example.chary

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Foreground service so audio recording keeps running when the screen locks or the app
 * is closed. Audio is piped straight into encrypted chunks: no unencrypted audio file
 * is ever written to storage.
 */
class EvidenceService : Service() {
    private var recorder: MediaRecorder? = null
    private var reader: Thread? = null
    private val handler = Handler(Looper.getMainLooper())
    private var exec: ExecutorService? = null
    private var recId: String? = null

    companion object {
        /** The recording in progress, if any (read by the uploader so it does not mark it finished). */
        @Volatile var activeId: String? = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1001, n)
        }
        val id = intent?.getStringExtra("id")
        if (id == null) { stopSelf(); return START_NOT_STICKY }
        startRecording(id)
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder =
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel("chary_safety", "Safety", NotificationManager.IMPORTANCE_LOW)
                )
                Notification.Builder(this, "chary_safety")
            } else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }
        val disguised = getSharedPreferences("chary_native", Context.MODE_PRIVATE).getBoolean("disguised", false)
        return b.setContentTitle(if (disguised) "Calculator" else "Chary is active")
            .setContentText(if (disguised) "Running" else "Safety mode running")
            .setSmallIcon(applicationInfo.icon)
            .setOngoing(true)
            .build()
    }

    private fun startRecording(id: String) {
        if (recorder != null) return
        try {
            val pipe = ParcelFileDescriptor.createPipe()
            val rec: MediaRecorder =
                if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this)
                else @Suppress("DEPRECATION") MediaRecorder()
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(64000)
            rec.setAudioSamplingRate(44100)
            rec.setOutputFile(pipe[1].fileDescriptor)
            rec.prepare()
            rec.start()
            pipe[1].close() // so the reader sees end-of-stream when recording stops
            recorder = rec

            val input = ParcelFileDescriptor.AutoCloseInputStream(pipe[0])
            val file = EvidenceStore.audioFile(this, id)
            // Live upload: full parts go to a separate thread so reading the microphone never waits on the network.
            val app = applicationContext
            val uploading = EvidenceUploader.token(app, id) != null && EvidenceUploader.configured(app)
            val ex = if (uploading) Executors.newSingleThreadExecutor() else null
            exec = ex
            recId = id
            activeId = id
            val live = if (ex != null) EvidenceUploader.SegmentSink { seq, buf, len ->
                val copy = buf.copyOf(len)
                try { ex.execute { EvidenceUploader.uploadSegment(app, id, seq, copy, len) } } catch (_: Exception) {}
            } else null
            reader = Thread {
                try {
                    FileOutputStream(file, true).use { fos ->
                        val buf = ByteArray(8192)
                        var lastSync = System.currentTimeMillis()
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            if (n > 0) {
                                EvidenceStore.writeChunk(fos, buf, n)
                                live?.write(buf, 0, n)
                                val now = System.currentTimeMillis()
                                if (now - lastSync > 1000) { fos.fd.sync(); lastSync = now }
                            }
                        }
                        fos.fd.sync()
                    }
                    live?.finish()
                } catch (_: Exception) {
                } finally {
                    try { input.close() } catch (_: Exception) {}
                }
            }.also { it.start() }

            // Safety limit: stop automatically after 3 hours.
            handler.postDelayed({ stopSelf() }, 3L * 60 * 60 * 1000)
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun stopRecording() {
        handler.removeCallbacksAndMessages(null)
        recorder?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        recorder = null
        try { reader?.join(1500) } catch (_: Exception) {}
        val r = reader
        val ex = exec
        val id = recId
        reader = null
        exec = null
        recId = null
        if (id != null) {
            // Finish uploading in the background, then re-send anything that failed.
            val app = applicationContext
            Thread {
                try { r?.join(8000) } catch (_: Exception) {}
                try {
                    ex?.shutdown()
                    ex?.awaitTermination(2, TimeUnit.MINUTES)
                } catch (_: Exception) {}
                if (activeId == id) activeId = null
                EvidenceUploader.sync(app, id)
            }.start()
        }
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }
}
