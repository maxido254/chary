package com.example.chary

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream

class MainActivity : FlutterActivity() {
    private var player: MediaPlayer? = null
    private var evPlayer: MediaPlayer? = null
    private var strobing = false
    private var torchOn = false
    private var torchId: String? = null
    private var savedVolume = -1
    private val handler = Handler(Looper.getMainLooper())

    // Set when the Quick Settings tile launched us; Dart reads and clears it with "consumeSos".
    private var pendingSos = false

    private fun readIntent(i: Intent?) {
        if (i != null && i.action == ACTION_SOS) {
            pendingSos = true
            i.action = Intent.ACTION_MAIN // do not re-trigger on rotation / re-creation
        }
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        readIntent(intent)
        super.onCreate(savedInstanceState)
    }

    override fun onNewIntent(intent: Intent) {
        readIntent(intent)
        super.onNewIntent(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "chary/sms")
            .setMethodCallHandler { call, result ->
                val id = call.argument<String>("id")
                when (call.method) {
                    "sendSms" -> sendSms(call.argument<String>("number"), call.argument<String>("text"), result)
                    "consumeSos" -> { val p = pendingSos; pendingSos = false; result.success(p) }
                    "getAcks" -> result.success(
                        (getSharedPreferences(AckReceiver.PREFS, Context.MODE_PRIVATE)
                            .getStringSet(AckReceiver.KEY, emptySet()) ?: emptySet()).toList()
                    )
                    "clearAcks" -> {
                        getSharedPreferences(AckReceiver.PREFS, Context.MODE_PRIVATE).edit().clear().apply()
                        result.success(true)
                    }
                    "setDisguise" -> { setDisguise(call.argument<Boolean>("on") == true); result.success(true) }
                    "setTaskLabel" -> { setTaskLabel(call.argument<String>("label") ?: "Chary"); result.success(true) }
                    "adminActive" -> result.success(adminActive())
                    "requestAdmin" -> { requestAdmin(); result.success(true) }
                    "removeAdmin" -> { removeAdmin(); result.success(true) }
                    "startAlarm" -> { startAlarm(); result.success(true) }
                    "stopAlarm" -> { stopAlarm(); result.success(true) }
                    "setUploadConfig" -> {
                        EvidenceUploader.setConfig(this, call.argument<String>("url"), call.argument<String>("key"))
                        result.success(true)
                    }
                    "startEvidence" -> startEvidence(id, call.argument<String>("meta"), call.argument<String>("token"), result)
                    "syncEvidence" -> {
                        if (id != null) Thread { EvidenceUploader.sync(applicationContext, id) }.start()
                        else EvidenceUploader.syncAll(this)
                        result.success(true)
                    }
                    "prepareShare" -> prepareShare(id, result)
                    "stopEvidence" -> {
                        stopService(Intent(this, EvidenceService::class.java))
                        result.success(true)
                    }
                    "updateEvidenceMeta" -> {
                        val meta = call.argument<String>("meta")
                        if (id != null && meta != null) {
                            try { EvidenceStore.writeMeta(this, id, meta) } catch (_: Exception) {}
                            EvidenceUploader.putMeta(this, id, meta)
                        }
                        result.success(true)
                    }
                    "listEvidence" -> listEvidence(result)
                    "playEvidence" -> playEvidence(id, result)
                    "stopPlayback" -> { stopPlayback(); result.success(true) }
                    "exportEvidence" -> exportEvidence(id, result)
                    "deleteEvidence" -> {
                        if (id != null) {
                            EvidenceStore.delete(this, id)
                            EvidenceUploader.forget(this, id)
                        }
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ---------- Disguise (launcher icon + name) ----------

    private fun setDisguise(on: Boolean) {
        getSharedPreferences("chary_native", Context.MODE_PRIVATE).edit().putBoolean("disguised", on).apply()
        val pm = packageManager
        val def = ComponentName(packageName, "$packageName.DefaultAlias")
        val calc = ComponentName(packageName, "$packageName.CalcAlias")
        val enable = PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        val disable = PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        // enable the new one first so there is never a moment with no launcher entry
        pm.setComponentEnabledSetting(if (on) calc else def, enable, PackageManager.DONT_KILL_APP)
        pm.setComponentEnabledSetting(if (on) def else calc, disable, PackageManager.DONT_KILL_APP)
    }

    /** The name shown in the recent-apps switcher. */
    @Suppress("DEPRECATION")
    private fun setTaskLabel(label: String) {
        try { setTaskDescription(ActivityManager.TaskDescription(label)) } catch (_: Exception) {}
    }

    // ---------- Device admin (blocks uninstall until switched off) ----------

    private fun adminComponent() = ComponentName(this, ChaDeviceAdmin::class.java)

    private fun adminActive(): Boolean =
        (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(adminComponent())

    private fun requestAdmin() {
        try {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent())
                .putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "While this is on, the app cannot be uninstalled until you switch it off."
                )
            startActivity(i)
        } catch (_: Exception) {}
    }

    private fun removeAdmin() {
        try {
            (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).removeActiveAdmin(adminComponent())
        } catch (_: Exception) {}
    }

    // ---------- Evidence ----------

    private fun startEvidence(id: String?, meta: String?, token: String?, result: MethodChannel.Result) {
        if (id == null || meta == null) { result.error("BAD_ARGS", "id/meta missing", null); return }
        try {
            // Timestamp + location are saved (encrypted) even if the microphone is not allowed.
            EvidenceStore.writeMeta(this, id, meta)
        } catch (e: Exception) {
            result.error("META_FAILED", e.message, null); return
        }
        EvidenceUploader.setToken(this, id, token)
        EvidenceUploader.putMeta(this, id, meta)
        val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (micOk) {
            try {
                val i = Intent(this, EvidenceService::class.java).putExtra("id", id)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } catch (_: Exception) {}
        }
        result.success(micOk)
    }

    private fun listEvidence(result: MethodChannel.Result) {
        Thread {
            val out = ArrayList<Map<String, Any>>()
            try {
                EvidenceStore.dir(this)
                    .listFiles { f -> f.extension == "meta" }
                    ?.sortedByDescending { it.lastModified() }
                    ?.forEach { f ->
                        val id = f.nameWithoutExtension
                        out.add(
                            mapOf(
                                "id" to id,
                                "meta" to EvidenceStore.readMeta(this, id),
                                "audioBytes" to EvidenceStore.audioFile(this, id).length(),
                                "upload" to EvidenceUploader.status(this, id),
                                "token" to (EvidenceUploader.token(this, id) ?: "")
                            )
                        )
                    }
            } catch (_: Exception) {}
            runOnUiThread { result.success(out) }
        }.start()
    }

    private fun playEvidence(id: String?, result: MethodChannel.Result) {
        if (id == null) { result.success(false); return }
        Thread {
            try {
                val tmp = File(cacheDir, "play.aac")
                FileOutputStream(tmp).use { EvidenceStore.decryptTo(EvidenceStore.audioFile(this, id), it) }
                runOnUiThread {
                    try {
                        stopPlayback()
                        val mp = MediaPlayer()
                        mp.setDataSource(tmp.absolutePath)
                        mp.setOnCompletionListener { stopPlayback() }
                        mp.prepare()
                        mp.start()
                        evPlayer = mp
                        result.success(true)
                    } catch (_: Exception) {
                        result.success(false)
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { result.success(false) }
            }
        }.start()
    }

    private fun stopPlayback() {
        try { evPlayer?.stop(); evPlayer?.release() } catch (_: Exception) {}
        evPlayer = null
        File(cacheDir, "play.aac").delete()
    }

    // Writes a DECRYPTED copy you can hand to police or a lawyer. Delete it afterwards.
    private fun exportEvidence(id: String?, result: MethodChannel.Result) {
        if (id == null) { result.success(null); return }
        Thread {
            var path: String? = null
            try {
                val base = getExternalFilesDir(null) ?: filesDir
                val dir = File(base, "exports").also { it.mkdirs() }
                val f = File(dir, "chary-evidence-$id.aac")
                FileOutputStream(f).use { EvidenceStore.decryptTo(EvidenceStore.audioFile(this, id), it) }
                path = f.absolutePath
            } catch (_: Exception) {}
            runOnUiThread { result.success(path) }
        }.start()
    }

    /**
     * Decrypts a copy into the cache folder for the share sheet. Old copies are removed first,
     * so a decrypted file never stays on the phone for long.
     */
    private fun prepareShare(id: String?, result: MethodChannel.Result) {
        if (id == null) { result.success(null); return }
        Thread {
            var path: String? = null
            try {
                val dir = File(cacheDir, "share").also { it.mkdirs() }
                val cutoff = System.currentTimeMillis() - 60 * 60 * 1000
                dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
                val f = File(dir, "evidence-$id.aac")
                FileOutputStream(f).use { EvidenceStore.decryptTo(EvidenceStore.audioFile(this, id), it) }
                path = f.absolutePath
            } catch (_: Exception) {}
            runOnUiThread { result.success(path) }
        }.start()
    }

    // ---------- SMS ----------

    // Returns true only if the phone network accepted every part of the message.
    private fun sendSms(number: String?, text: String?, result: MethodChannel.Result) {
        if (number == null || text == null) {
            result.error("BAD_ARGS", "number/text missing", null)
            return
        }
        try {
            val sm: SmsManager =
                if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java)
                else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            val action = "com.example.chary.SMS_SENT_" + System.nanoTime()
            var remaining = parts.size
            var allOk = true
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    if (resultCode != Activity.RESULT_OK) allOk = false
                    remaining--
                    if (remaining == 0) {
                        try { unregisterReceiver(this) } catch (_: Exception) {}
                        result.success(allOk)
                    }
                }
            }
            val filter = IntentFilter(action)
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                registerReceiver(receiver, filter)
            }
            val sentIntents = ArrayList<PendingIntent>()
            for (k in parts.indices) {
                sentIntents.add(
                    PendingIntent.getBroadcast(
                        this, k, Intent(action).setPackage(packageName), PendingIntent.FLAG_IMMUTABLE
                    )
                )
            }
            sm.sendMultipartTextMessage(number, null, parts, sentIntents, null)
        } catch (e: Exception) {
            result.error("SMS_FAILED", e.message, null)
        }
    }

    // ---------- Alarm + flashlight ----------

    private fun startAlarm() {
        if (player != null) return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            savedVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            val afd = resources.openRawResourceFd(R.raw.siren)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (_: Exception) {}
        startStrobe()
    }

    private fun startStrobe() {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            strobing = true
            val tick = object : Runnable {
                override fun run() {
                    if (!strobing) return
                    torchOn = !torchOn
                    try { cm.setTorchMode(torchId!!, torchOn) } catch (_: Exception) {}
                    handler.postDelayed(this, 200)
                }
            }
            handler.post(tick)
        } catch (_: Exception) {}
    }

    private fun stopAlarm() {
        strobing = false
        handler.removeCallbacksAndMessages(null)
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId?.let { cm.setTorchMode(it, false) }
        } catch (_: Exception) {}
        torchOn = false
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        player = null
        if (savedVolume >= 0) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0)
            } catch (_: Exception) {}
            savedVolume = -1
        }
    }

    override fun onDestroy() {
        stopAlarm()
        stopPlayback()
        super.onDestroy() // the evidence service keeps recording on purpose
    }

    companion object {
        const val ACTION_SOS = "com.example.chary.SOS"
    }
}
