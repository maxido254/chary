package com.example.chary

import android.os.Build
import android.telephony.SmsManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "chary/sms")
            .setMethodCallHandler { call, result ->
                if (call.method == "sendSms") {
                    val number = call.argument<String>("number")
                    val text = call.argument<String>("text")
                    if (number == null || text == null) {
                        result.error("BAD_ARGS", "number/text missing", null)
                        return@setMethodCallHandler
                    }
                    try {
                        val sm: SmsManager =
                            if (Build.VERSION.SDK_INT >= 31)
                                getSystemService(SmsManager::class.java)
                            else
                                @Suppress("DEPRECATION") SmsManager.getDefault()
                        sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null)
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("SMS_FAILED", e.message, null)
                    }
                } else {
                    result.notImplemented()
                }
            }
    }
}
