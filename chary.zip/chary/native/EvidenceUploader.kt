package com.chary.app

import android.content.Context
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Uploads evidence audio to the optional relay in fixed-size parts. Part N is always bytes
 * [N*SEG, (N+1)*SEG) of the audio stream, so the live uploader (while recording) and the
 * catch-up sync (after a failed upload) agree on part numbers and re-sending is harmless.
 */
object EvidenceUploader {
    const val SEG = 96_000 // about 12 seconds of audio at 64 kbps
    private const val PREFS = "chary_upload"
    private val io = Executors.newSingleThreadExecutor()

    fun setConfig(ctx: Context, url: String?, key: String?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("url", (url ?: "").trim().trimEnd('/'))
            .putString("key", key ?: "")
            .apply()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun configured(ctx: Context) = !prefs(ctx).getString("url", "").isNullOrEmpty()

    fun setToken(ctx: Context, id: String, token: String?) {
        if (token.isNullOrEmpty()) return
        prefs(ctx).edit().putString("tok_$id", token).putBoolean("done_$id", false).apply()
        QueueRetry.schedule(ctx) // keep trying in the background if there is no data right now
    }

    fun token(ctx: Context, id: String): String? = prefs(ctx).getString("tok_$id", null)

    /** "none" (not uploading), "partial" or "done". */
    fun status(ctx: Context, id: String): String = when {
        token(ctx, id) == null -> "none"
        prefs(ctx).getBoolean("done_$id", false) -> "done"
        else -> "partial"
    }

    @Synchronized
    private fun mark(ctx: Context, id: String, seq: Int, len: Int) {
        val p = prefs(ctx)
        val set = HashSet(p.getStringSet("seg_$id", emptySet()) ?: emptySet())
        set.add("$seq:$len")
        p.edit().putStringSet("seg_$id", set).apply()
    }

    private fun isUploaded(ctx: Context, id: String, seq: Int, len: Int): Boolean =
        (prefs(ctx).getStringSet("seg_$id", emptySet()) ?: emptySet()).contains("$seq:$len")

    private fun post(ctx: Context, path: String, body: ByteArray, len: Int, contentType: String): Boolean {
        val p = prefs(ctx)
        val base = p.getString("url", "") ?: ""
        if (base.isEmpty()) return false
        return try {
            val c = URL("$base$path").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.doOutput = true
            c.setFixedLengthStreamingMode(len)
            c.setRequestProperty("Content-Type", contentType)
            c.setRequestProperty("X-Key", p.getString("key", "") ?: "")
            c.outputStream.use { it.write(body, 0, len) }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (_: Exception) {
            false
        }
    }

    fun uploadSegment(ctx: Context, id: String, seq: Int, buf: ByteArray, len: Int): Boolean {
        val tok = token(ctx, id) ?: return false
        if (isUploaded(ctx, id, seq, len)) return true
        val ok = post(ctx, "/evidence/$tok/$seq", buf, len, "application/octet-stream")
        if (ok) mark(ctx, id, seq, len)
        return ok
    }

    /** Time and location, so the guardian's page can show a map link. */
    fun putMeta(ctx: Context, id: String, json: String) {
        val tok = token(ctx, id) ?: return
        if (!configured(ctx)) return
        val app = ctx.applicationContext
        io.execute {
            val b = json.toByteArray(Charsets.UTF_8)
            post(app, "/evidence/$tok/meta", b, b.size, "application/json")
        }
    }

    /** Collects a byte stream into SEG-sized parts and hands each full part to [onPart]. */
    class SegmentSink(private val onPart: (seq: Int, buf: ByteArray, len: Int) -> Unit) : OutputStream() {
        private val buf = ByteArray(SEG)
        private var n = 0
        private var seq = 0

        override fun write(b: Int) { write(byteArrayOf(b.toByte()), 0, 1) }

        override fun write(b: ByteArray, off: Int, len: Int) {
            var o = off
            var left = len
            while (left > 0) {
                val c = minOf(left, SEG - n)
                System.arraycopy(b, o, buf, n, c)
                n += c; o += c; left -= c
                if (n == SEG) { onPart(seq, buf, n); seq++; n = 0 }
            }
        }

        /** Sends the last, shorter part. */
        fun finish() {
            if (n > 0) { onPart(seq, buf, n); n = 0; seq++ }
        }
    }

    /**
     * Catch-up: re-reads the encrypted file and uploads every part the relay has not confirmed.
     * Returns true when everything is uploaded (or there is nothing to upload).
     */
    fun sync(ctx: Context, id: String): Boolean {
        val tok = token(ctx, id) ?: return true
        if (!configured(ctx)) return false
        var allOk = true
        try {
            val sink = SegmentSink { seq, buf, len ->
                if (!uploadSegment(ctx, id, seq, buf, len)) allOk = false
            }
            val f: File = EvidenceStore.audioFile(ctx, id)
            EvidenceStore.decryptTo(f, sink)
            sink.finish()
        } catch (_: Exception) {
            allOk = false
        }
        if (allOk && EvidenceService.activeId != id) {
            prefs(ctx).edit().putBoolean("done_$id", true).apply()
        }
        return allOk
    }

    /** Catch-up for every recording that still has parts to send. Runs on a background thread. */
    fun syncAll(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            try {
                EvidenceStore.dir(app).listFiles { f -> f.extension == "meta" }?.forEach { f ->
                    val id = f.nameWithoutExtension
                    if (status(app, id) == "partial" && EvidenceService.activeId != id) sync(app, id)
                }
            } catch (_: Exception) {}
        }.start()
    }

    fun forget(ctx: Context, id: String) {
        prefs(ctx).edit().remove("tok_$id").remove("seg_$id").remove("done_$id").apply()
    }
}
