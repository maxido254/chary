package com.example.chary

import android.app.admin.DeviceAdminReceiver

/**
 * Holds no policies. Being an active device admin only has one effect we want:
 * Android will not uninstall the app until admin is switched off first.
 */
class ChaDeviceAdmin : DeviceAdminReceiver()
