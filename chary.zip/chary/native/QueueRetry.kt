package com.chary.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

/**
 * Keeps trying in the background, with the app closed, until a saved alert gets through:
 *  - SMS that failed (no airtime / no signal) are re-sent every ~10 minutes,
 *  - evidence audio that could not upload (no data) is re-sent.
 * The saved SMS queue is the one the Dart side keeps in shared preferences.
 */
object QueueRetry {
    private const val FLUTTER_PREFS = "FlutterSharedPreferences"
    private const val QUEUE_KEY = "flutter.pending_queue"
    private const val INTERVAL_MS = 10 * 60 * 1000L

    private fun readQueue(ctx: Context): List<Pair<String, String>> {
        val raw = ctx.getSharedPreferences(FLUTTER_PREFS, Context.MODE_PRIVATE).getString(QUEUE_KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                val o = arr.getJSONObject(it)
                val p = o.optString("phone"); val t = o.optString("text")
                if (p.isEmpty() || t.isEmpty()) null else p to t
            }
        } catch (_: Exception) { emptyList() }
    }

    /** Removes only the messages we sent, re-reading first so anything queued meanwhile survives. */
    @Synchronized
    private fun removeSent(ctx: Context, sent: List<Pair<String, String>>) {
        if (sent.isEmpty()) return
        val left = readQueue(ctx).toMutableList()
        for (s in sent) left.remove(s)
        val arr = JSONArray()
        for ((p, t) in left) arr.put(JSONObject().put("phone", p).put("text", t))
        ctx.getSharedPreferences(FLUTTER_PREFS, Context.MODE_PRIVATE).edit()
            .putString(QUEUE_KEY, arr.toString()).apply()
    }

    private fun pendingEvidence(ctx: Context): List<String> = try {
        EvidenceStore.dir(ctx).listFiles { f -> f.extension == "meta" }
            ?.map { it.nameWithoutExtension }
            ?.filter { EvidenceUploader.status(ctx, it) == "partial" && EvidenceService.activeId != it }
            ?: emptyList()
    } catch (_: Exception) { emptyList() }

    fun needsRetry(ctx: Context): Boolean = readQueue(ctx).isNotEmpty() || pendingEvidence(ctx).isNotEmpty()

    private fun pi(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 4711, Intent(ctx, RetryReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + INTERVAL_MS, pi(ctx))
        } catch (_: Exception) {}
    }

    fun cancel(ctx: Context) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(ctx)) } catch (_: Exception) {}
    }

    /** One pass. Blocking: call from a background thread. */
    fun run(ctx: Context) {
        val sent = ArrayList<Pair<String, String>>()
        for (m in readQueue(ctx)) {
            if (SmsSender.send(ctx, m.first, m.second)) sent.add(m)
        }
        removeSent(ctx, sent)
        for (id in pendingEvidence(ctx)) EvidenceUploader.sync(ctx, id)
        if (needsRetry(ctx)) schedule(ctx) else cancel(ctx)
    }
}

/** Fired by the alarm (and after a reboot). Runs one retry pass, then re-arms itself if work remains. */
class RetryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val result = goAsync()
        Thread {
            try {
                QueueRetry.run(app)
            } catch (_: Exception) {
                QueueRetry.schedule(app)
            } finally {
                result.finish()
            }
        }.start()
    }
}

/** After a reboot the alarm is gone, so re-arm it if there is still something to send. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && QueueRetry.needsRetry(context)) {
            QueueRetry.schedule(context)
        }
    }
}
