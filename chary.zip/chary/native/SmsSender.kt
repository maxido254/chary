package com.chary.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.telephony.SmsManager
import java.util.concurrent.CountDownLatch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.TimeUnit

/** Sends one SMS and waits for the network's answer. Must NOT be called on the main thread. */
object SmsSender {
    /** True only if the network accepted every part. False on no airtime, no signal, or timeout. */
    fun send(ctx: Context, number: String, text: String, timeoutSeconds: Long = 30): Boolean {
        return try {
            val sm: SmsManager =
                if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                else @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sm.divideMessage(text)
            val action = "com.chary.app.SMS_BG_" + System.nanoTime()
            val latch = CountDownLatch(parts.size)
            val allOk = AtomicBoolean(true)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(c: Context?, i: Intent?) {
                    if (resultCode != Activity.RESULT_OK) allOk.set(false)
                    latch.countDown()
                }
            }
            val filter = IntentFilter(action)
            if (Build.VERSION.SDK_INT >= 33) {
                ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                ctx.registerReceiver(receiver, filter)
            }
            try {
                val sent = ArrayList<PendingIntent>()
                for (k in parts.indices) {
                    sent.add(
                        PendingIntent.getBroadcast(
                            ctx, k, Intent(action).setPackage(ctx.packageName), PendingIntent.FLAG_IMMUTABLE
                        )
                    )
                }
                sm.sendMultipartTextMessage(number, null, parts, sent, null)
                latch.await(timeoutSeconds, TimeUnit.SECONDS) && allOk.get()
            } finally {
                try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            false
        }
    }
}
