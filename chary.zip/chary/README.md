# Chary

One-press emergency alert app. Hold the SOS button for 3 seconds and your GPS location is texted to your saved guardians. No server, no accounts, no cost.

## Run it
```bash
git clone <your-repo-url> && cd chary
./setup.sh        # generates android/ios folders and wires in native SMS
flutter run       # with a real phone connected (SMS does not work on emulators)
```

## What works now (v0.1)
- 3-second hold SOS button (prevents accidental sends)
- Up to 5 guardians, stored only on the device
- GPS location link in the message (falls back to last known position)
- Android: sends SMS silently in the background via `SmsManager`
- iOS: opens Messages pre-filled (iOS blocks silent SMS); user taps Send once
- Failed messages are queued and retried every 30 s while the app is open
- "Call emergency" button (number set in `lib/sos_service.dart`, default 112)

## Offline, alarm and powered-off phones (v0.2)
- The first SMS goes out immediately with the last known location, then a second "UPDATED LOCATION" SMS follows when a fresh GPS fix arrives. The alert is out before the phone can be taken.
- SMS needs cellular signal only, not internet. Android now reports whether the network really accepted each SMS. Rejected ones are queued and retried every 30 s and on app start.
- Loud siren at maximum alarm volume plus flashlight strobe on SOS. A switch turns this off for a silent alert. Hold-to-stop button.
- A switched-off phone cannot run any app. Pair Chary with the phone's own Find My / Find Hub.

## Evidence capture (v0.3, Android)
- One tap (or automatically on SOS) saves timestamp, location and audio.
- Everything is AES-256-GCM encrypted with a key in the Android Keystore. No unencrypted audio is ever written to storage.
- Audio is stored in small independent encrypted chunks, so a recording survives the phone dying mid-recording.
- Recording runs in a foreground service (shows a discreet "Chary is active" notification), so it continues when the screen locks. Auto-stops after 3 hours.
- Evidence screen: play, export a decrypted copy (for police or a lawyer), delete.
- Not backed up anywhere: if the phone is lost, so is the evidence. Recording laws on consent vary by country; check yours.
- Anyone who unlocks the phone and opens Chary can see or delete evidence. A PIN lock is the next step.

## No airtime? (v0.4)
Delivery order per guardian: SMS, then internet relay, then queue + retry.
- Relay (data/Wi-Fi, no airtime): needs the optional relay in `relay/` (costs you SMS credit).
- WhatsApp button (data/Wi-Fi): pre-filled message, the person taps Send once.
- Calls to 112 and the toll-free GBV helpline 1195 are one tap away.
- If there is no airtime, no data and no Wi-Fi, nothing can carry a message except calling 112/999.

## Roadmap
1. Lock-screen trigger (Android quick-settings tile / power-button gesture)
2. Foreground service so retries continue when the app is closed
3. Alarm + flashlight strobe
4. Firebase FCM push + guardian companion app with "I'm on my way"
5. Satellite fallback (hand off to OS Emergency SOS) and BLE mesh relay
6. Encrypted evidence log, disguise mode

## Honest limits
With no cellular, Wi-Fi or satellite and no nearby phones, no app can deliver a message. This app queues it and sends the moment any path opens. For true no-signal cases, the phone's built-in Emergency SOS (satellite on supported models) remains the most reliable option.

## Privacy
Guardian numbers and the queue live in local storage on the device. Nothing is sent to any server. Add encryption (e.g. `flutter_secure_storage`) before releasing publicly.

## Privacy and discreet use (v0.5)
All of this is in Settings (gear icon on the home screen).
- **App PIN**: 4 to 8 digits, stored as a salted hash. The app locks again after 30 seconds in the background (you choose). Back cannot get past the lock. **SOS still works from the lock screen without the PIN**: hold the red button for 3 seconds. Stopping the alarm needs the PIN.
- **Calculator disguise**: the launcher icon, name, recent-apps title and the recording notification all say "Calculator", and the app opens as a working calculator. Type your PIN then `=` to open Chary. **Hold `%` for 3 seconds** to send an SOS (a firm buzz confirms it, nothing is drawn on screen). The icon can take a few seconds to change. Forgot the PIN: clear the app data in Android Settings (erases guardians and evidence).
- **Quick Settings tile**: add "Chary SOS" (swipe down, Edit). Tapping it opens a 5 second countdown with a Cancel button, then sends the alert even while the app is PIN locked. The phone itself must be unlocked, Android does not let tiles run on a locked screen.
- **Guardian replies**: the alert asks guardians to reply. The app records only WHO texted back (never the text) and ticks them off. If someone has not replied after 2, 5 or 10 minutes (default 5), they get a reminder with fresh location, up to 3 times. Holding the black stop button cancels pending reminders. Reminders and reply tracking need the app process to stay alive (it does while recording evidence); if Android kills the app, they stop. Replies to alerts sent through the internet relay come from the relay's number and are not matched.
- **Block uninstall**: makes Chary a device admin (no powers, no policies) so Android refuses to uninstall it until you switch this off. It adds friction only: anyone who knows your phone passcode can still switch it off in Android Settings.
- Not built: auto-dialling a guardian or emergency number (needs `CALL_PHONE`, accidental calls, no clean way to cancel). The Call buttons remain one tap.

## Getting evidence out (v0.6)
- **Automatic upload** (needs the relay, see `relay/README.md`, plus data or Wi-Fi): audio is sent to your relay in ~12 second parts while recording, and the alert SMS carries a "Listen live" link that opens in any phone browser. Parts that fail are retried every 30 seconds and when the recording stops, so the whole recording arrives once the phone has data. Alerts only: "Record evidence now" stays on the phone.
- **Manual backup**: Evidence screen has Share (WhatsApp, email, Drive...), Copy listen link and Upload now. Share decrypts a temporary copy in the cache folder, removed within an hour.
- Without a relay configured, nothing leaves the phone except by Share.
- Limits: if the phone is destroyed or offline for the whole time, only the parts that already uploaded exist. The audio on the relay is not end-to-end encrypted.
