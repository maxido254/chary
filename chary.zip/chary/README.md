# Chary

One-press emergency alert app. Hold the SOS button for 3 seconds and your GPS location is texted to your saved guardians. No server, no accounts, no cost.

## Run it
```bash
git clone <your-repo-url> && cd chary
./setup.sh        # generates android/ios folders and wires in native SMS
flutter run       # with a real phone connected (SMS does not work on emulators)
```

## What works now (v0.1)
- 3-second hold SOS button (prevents accidental sends)
- Up to 5 guardians, stored only on the device
- GPS location link in the message (falls back to last known position)
- Android: sends SMS silently in the background via `SmsManager`
- iOS: opens Messages pre-filled (iOS blocks silent SMS); user taps Send once
- Failed messages are queued and retried every 30 s while the app is open
- "Call emergency" button (number set in `lib/sos_service.dart`, default 112)

## Roadmap
1. Lock-screen trigger (Android quick-settings tile / power-button gesture)
2. Foreground service so retries continue when the app is closed
3. Alarm + flashlight strobe
4. Firebase FCM push + guardian companion app with "I'm on my way"
5. Satellite fallback (hand off to OS Emergency SOS) and BLE mesh relay
6. Encrypted evidence log, disguise mode

## Honest limits
With no cellular, Wi-Fi or satellite and no nearby phones, no app can deliver a message. This app queues it and sends the moment any path opens. For true no-signal cases, the phone's built-in Emergency SOS (satellite on supported models) remains the most reliable option.

## Privacy
Guardian numbers and the queue live in local storage on the device. Nothing is sent to any server. Add encryption (e.g. `flutter_secure_storage`) before releasing publicly.
