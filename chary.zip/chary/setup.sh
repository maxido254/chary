#!/usr/bin/env bash
# Run once after cloning: generates the android/ios folders and wires in native code + permissions.
set -e
command -v flutter >/dev/null || { echo "Install Flutter first: https://docs.flutter.dev/get-started/install"; exit 1; }

flutter create --org com.example --project-name chary --platforms android,ios .
# the generated sample test refers to a MyApp class this project does not have
rm -f test/widget_test.dart
flutter pub get

DEST=android/app/src/main/kotlin/com/example/chary
mkdir -p "$DEST"
cp native/*.kt "$DEST/"
mkdir -p android/app/src/main/res/raw
cp native/siren.wav android/app/src/main/res/raw/siren.wav
cp -r native/res/. android/app/src/main/res/

python3 - <<'PY'
import re
p='android/app/src/main/AndroidManifest.xml'
s=open(p).read()
perms='''
    <uses-permission android:name="android.permission.SEND_SMS"/>
    <uses-permission android:name="android.permission.RECEIVE_SMS"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-feature android:name="android.hardware.telephony" android:required="false"/>
    <queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent></queries>'''
if 'SEND_SMS' not in s:
    s=re.sub(r'(<manifest[^>]*>)', r'\1'+perms, s, count=1)
if 'EvidenceService' not in s:
    s=s.replace('</application>','    <service android:name=".EvidenceService" android:exported="false" android:foregroundServiceType="microphone"/>\n    </application>',1)

# Launcher entry moves from MainActivity to two aliases so the icon/name can be swapped (calculator disguise).
if 'DefaultAlias' not in s:
    s=re.sub(r'\s*<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*/>\s*<category android:name="android.intent.category.LAUNCHER"\s*/>\s*</intent-filter>','',s,count=1)
    extra='''
    <activity-alias android:name=".DefaultAlias" android:targetActivity=".MainActivity"
        android:enabled="true" android:exported="true" android:label="Chary" android:icon="@mipmap/ic_launcher">
        <intent-filter>
            <action android:name="android.intent.action.MAIN"/>
            <category android:name="android.intent.category.LAUNCHER"/>
        </intent-filter>
    </activity-alias>
    <activity-alias android:name=".CalcAlias" android:targetActivity=".MainActivity"
        android:enabled="false" android:exported="true" android:label="Calculator" android:icon="@mipmap/ic_calc">
        <intent-filter>
            <action android:name="android.intent.action.MAIN"/>
            <category android:name="android.intent.category.LAUNCHER"/>
        </intent-filter>
    </activity-alias>
    <receiver android:name=".AckReceiver" android:exported="true" android:permission="android.permission.BROADCAST_SMS">
        <intent-filter><action android:name="android.provider.Telephony.SMS_RECEIVED"/></intent-filter>
    </receiver>
    <receiver android:name=".ChaDeviceAdmin" android:exported="true" android:permission="android.permission.BIND_DEVICE_ADMIN">
        <meta-data android:name="android.app.device_admin" android:resource="@xml/device_admin"/>
        <intent-filter><action android:name="android.app.action.DEVICE_ADMIN_ENABLED"/></intent-filter>
    </receiver>
    <service android:name=".SosTileService" android:exported="true" android:label="Chary SOS"
        android:icon="@drawable/ic_tile_sos" android:permission="android.permission.BIND_QUICK_SETTINGS_TILE">
        <intent-filter><action android:name="android.service.quicksettings.action.QS_TILE"/></intent-filter>
    </service>
    '''
    s=s.replace('</application>',extra+'</application>',1)
open(p,'w').write(s)

p='ios/Runner/Info.plist'
s=open(p).read()
add='''
	<key>NSLocationWhenInUseUsageDescription</key>
	<string>Your location is shared with your guardians only when you trigger an alert.</string>
	<key>LSApplicationQueriesSchemes</key>
	<array><string>sms</string><string>tel</string></array>'''
if 'NSLocationWhenInUse' not in s:
    s=s.replace('<dict>','<dict>'+add,1)
    open(p,'w').write(s)
PY

# (aliases already carry their own labels; only the application/activity labels are normalised here)
python3 - <<'PY3'
import re
p='android/app/src/main/AndroidManifest.xml'
s=open(p).read()
s=re.sub(r'(<(?:application|activity)(?![-\w])[^>]*?android:label=")[^"]*"',r'\1Chary"',s)
open(p,'w').write(s)
PY3
# Encrypted evidence storage needs Android 7+
sed -i 's/minSdk = flutter.minSdkVersion/minSdk = 24/' android/app/build.gradle.kts || true
python3 - <<'PY2'
import re
p='ios/Runner/Info.plist'
s=open(p).read()
s=re.sub(r'(<key>CFBundleDisplayName</key>\s*<string>)[^<]*',r'\1Chary',s)
open(p,'w').write(s)
PY2
echo "Done. Connect a phone and run: flutter run"
