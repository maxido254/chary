#!/usr/bin/env bash
# Run once after cloning: generates the android/ios folders and wires in native SMS + permissions.
set -e
command -v flutter >/dev/null || { echo "Install Flutter first: https://docs.flutter.dev/get-started/install"; exit 1; }

flutter create --org com.example --project-name chary --platforms android,ios .
flutter pub get

# Android: native SMS sender
DEST=android/app/src/main/kotlin/com/example/chary
mkdir -p "$DEST"
cp native/MainActivity.kt "$DEST/MainActivity.kt"

python3 - <<'PY'
import re
# Android permissions
p='android/app/src/main/AndroidManifest.xml'
s=open(p).read()
perms='''
    <uses-permission android:name="android.permission.SEND_SMS"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-feature android:name="android.hardware.telephony" android:required="false"/>
    <queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent></queries>'''
if 'SEND_SMS' not in s:
    s=re.sub(r'(<manifest[^>]*>)', r'\1'+perms, s, count=1)
    open(p,'w').write(s)
# iOS plist
p='ios/Runner/Info.plist'
s=open(p).read()
add='''
	<key>NSLocationWhenInUseUsageDescription</key>
	<string>Your location is shared with your guardians only when you trigger an alert.</string>
	<key>LSApplicationQueriesSchemes</key>
	<array><string>sms</string><string>tel</string></array>'''
if 'NSLocationWhenInUse' not in s:
    s=s.replace('<dict>','<dict>'+add,1)
    open(p,'w').write(s)
PY
sed -i 's/android:label="[^"]*"/android:label="Chary"/' android/app/src/main/AndroidManifest.xml
python3 - <<'PY2'
import re
p='ios/Runner/Info.plist'
s=open(p).read()
s=re.sub(r'(<key>CFBundleDisplayName</key>\s*<string>)[^<]*',r'\1Chary',s)
open(p,'w').write(s)
PY2
echo "Done. Connect a phone and run: flutter run"
